
package com.job.jobboard.controller;

import com.job.jobboard.model. Resume;

import com.job.jobboard.service.ResumeService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(value = "/api/v1")
public class ResumeController {

    @Autowired
    private ResumeService employerService;

    @GetMapping("/postresume")
    public List<Resume> getAllResume() {
        return employerService.getAllResume();
    }

    @PostMapping("/postresume")
    public Resume insertResume(@RequestBody Resume employee) {
        return employerService.insertResume(employee);
    }

    @GetMapping("/postresume/{persinfoid}")
    public ResponseEntity<Resume> getUser(@PathVariable("persinfoid") int persinfoid) {
        System.out.println("Fetching User with id " + persinfoid);
        Resume employer = employerService.viewOneResume(persinfoid);
        if (employer == null) {
            System.out.println("Resume with id " + persinfoid + " not found");
            return new ResponseEntity<Resume>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Resume>(employer, HttpStatus.OK);
    }

    @PutMapping("/postresume/{persinfoid}")
    public ResponseEntity<Resume> updateUser(@PathVariable("persinfoid") int persinfoid, @RequestBody Resume employee) {
        System.out.println("Updating Resume " + persinfoid);

        Resume currentResume = employerService.viewOneResume(persinfoid);

        if (currentResume == null) {
            System.out.println("User with id " + persinfoid + " not found");
            return new ResponseEntity<Resume>(HttpStatus.NOT_FOUND);
        }

        
      
        currentResume.setObjective(employee.getObjective());
        currentResume.setPersinfoid(employee.getPersinfoid());
        currentResume.setEmail(employee.getEmail());
        currentResume.setPhone(employee.getPhone());
        currentResume.setComname(employee.getComname());
        currentResume.setRole(employee.getRole());
        currentResume.setStartdate(employee.getStartdate());
        currentResume.setEnddate(employee.getEnddate());
        currentResume.setCompost(employee.getCompost());
        currentResume.setFname(employee.getFname());
        currentResume.setLname(employee.getLname());
        currentResume.setFaname(employee.getFaname());
        currentResume.setMoname(employee.getMoname());
        currentResume.setDob(employee.getDob());
        currentResume.setGender(employee.getGender());
        currentResume.setReligion(employee.getReligion());
        currentResume.setNationality(employee.getNationality());
        currentResume.setMaritul(employee.getMaritul());
        currentResume.setPreaddress(employee.getPreaddress());
        currentResume.setPeraddress(employee.getPeraddress());
        currentResume.setDegreeone(employee.getDegreeone());
        currentResume.setInstituteone(employee.getInstituteone());
        currentResume.setSubjectone(employee.getSubjectone());
        currentResume.setPassone(employee.getPassone());
        currentResume.setResultone(employee.getResultone());
        currentResume.setDegreetwo(employee.getDegreetwo());
        currentResume.setInstitutetwo(employee.getInstitutetwo());
        currentResume.setSubjecttwo(employee.getSubjecttwo());
        currentResume.setPasstwo(employee.getPasstwo());
        currentResume.setResulttwo(employee.getResulttwo());
        currentResume.setDegreethree(employee.getDegreethree());
        currentResume.setInstitutethree(employee.getInstitutethree());
        currentResume.setSubjectthree(employee.getSubjectthree());
        currentResume.setPassthree(employee.getPassthree());
        currentResume.setResultthree(employee.getResultthree());
        currentResume.setDegreefour(employee.getDegreefour());
        currentResume.setInstitutefour(employee.getInstitutefour());
        currentResume.setSubjectfour(employee.getSubjectfour());
        currentResume.setPassfour(employee.getPassfour());
        currentResume.setResultfour(employee.getResultfour());
        currentResume.setImgurl(employee.getImgurl());
         currentResume.setSkills(employee.getSkills());
       

        employerService.updateResume(currentResume);
        return new ResponseEntity<Resume>(currentResume, HttpStatus.OK);
    }

    @DeleteMapping("/postresume/{persinfoid}")
    public ResponseEntity<Resume> deleteUser(@PathVariable("persinfoid") int persinfoid) {
        System.out.println("Fetching & Deleting Resume with id " + persinfoid);

        Resume employer = employerService.viewOneResume(persinfoid);
        if (employer == null) {
            System.out.println("Unable to delete. Resume with id " + persinfoid + " not found");
            return new ResponseEntity<Resume>(HttpStatus.NOT_FOUND);
        }

        employerService.deleteResume(persinfoid);
        return new ResponseEntity<Resume>(HttpStatus.NO_CONTENT);
    }

}
