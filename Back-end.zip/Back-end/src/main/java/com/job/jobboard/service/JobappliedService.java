
package com.job.jobboard.service;

import com.job.jobboard.model.Jobapplied;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface JobappliedService {
    public Jobapplied insertJobapplied(Jobapplied cm);

    public void updateJobapplied(Jobapplied cm);

    public void deleteJobapplied(int areaid);

    public List<Jobapplied> viewJobapplied();

    public Jobapplied viewOneJobapplied(int areaid);
}
