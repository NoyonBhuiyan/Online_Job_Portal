
package com.job.jobboard.controller;

import com.job.jobboard.model. User;

import com.job.jobboard.service.UserService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/v1")
public class UserController {

    @Autowired
    private UserService areaService;

    @GetMapping("/users")
    public List<User> getAllUser() {
        return areaService.viewUser();
    }

    @PostMapping("/users")
    public User createUser(@RequestBody User area) {
        return areaService.insertUser(area);
    }

    @GetMapping("/users/{emailid}")
    public ResponseEntity<User> getUser(@PathVariable("emailid") String emailid) {
        System.out.println("Fetching User with id " + emailid);
        User area = areaService.viewOneUser(emailid);
        if (area == null) {
            System.out.println("User with id " + emailid + " not found");
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<User>(area, HttpStatus.OK);
    }

    @PutMapping("/users/{emailid}")
    public ResponseEntity<User> updateUser(@PathVariable("emailid") String emailid, @RequestBody User area) {
        System.out.println("Updating User " + emailid);

        User currentUser = areaService.viewOneUser(emailid);

        if (currentUser == null) {
            System.out.println("User with id " + emailid + " not found");
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }

         currentUser.setPhone(area.getPhone());
         currentUser.setEmailid(area.getEmailid());
          currentUser.setUsername(area.getUsername());
      
        
        areaService.updateUser(currentUser);
        return new ResponseEntity<User>(currentUser, HttpStatus.OK);
    }

    @DeleteMapping("/users/{emailid}")
    public ResponseEntity<User> deleteUser(@PathVariable("emailid") String emailid) {
        System.out.println("Fetching & Deleting User with id " + emailid);

        User area = areaService.viewOneUser(emailid);
        if (area == null) {
            System.out.println("Unable to delete. User with id " + emailid + " not found");
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }

        areaService.deleteUser(emailid);
        return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
    }

}
