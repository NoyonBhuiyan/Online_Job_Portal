package com.job.jobboard.service;

import com.job.jobboard.model.Resume;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface ResumeService {
    public Resume insertResume(Resume cm);

    public void updateResume(Resume cm);

    public void deleteResume(int persinfoid);

    public List<Resume> getAllResume();

    public Resume viewOneResume(int persinfoid);
}
