
package com.job.jobboard.controller;

import com.job.jobboard.model. Employee;

import com.job.jobboard.service.EmployeeService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(value = "/api/v1")
public class EmployeeController {

    @Autowired
    private EmployeeService employerService;

    @GetMapping("/employees")
    public List<Employee> getAllEmployee() {
        return employerService.getAllEmployee();
    }

    @PostMapping("/employees")
    public Employee insertEmployee(@RequestBody Employee employee) {
        return employerService.insertEmployee(employee);
    }

    @GetMapping("/employees/{persinfoid}")
    public ResponseEntity<Employee> getUser(@PathVariable("persinfoid") int persinfoid) {
        System.out.println("Fetching User with id " + persinfoid);
        Employee employer = employerService.viewOneEmployee(persinfoid);
        if (employer == null) {
            System.out.println("Employee with id " + persinfoid + " not found");
            return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Employee>(employer, HttpStatus.OK);
    }

    @PutMapping("/employees/{persinfoid}")
    public ResponseEntity<Employee> updateUser(@PathVariable("persinfoid") int persinfoid, @RequestBody Employee employee) {
        System.out.println("Updating Employee " + persinfoid);

        Employee currentEmployee = employerService.viewOneEmployee(persinfoid);

        if (currentEmployee == null) {
            System.out.println("User with id " + persinfoid + " not found");
            return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
        }

        
      
        currentEmployee.setUsername(employee.getUsername());
        currentEmployee.setPersinfoid(employee.getPersinfoid());
        currentEmployee.setGender(employee.getGender());
        currentEmployee.setEmailid(employee.getEmailid());
        currentEmployee.setPhone(employee.getPhone());
        currentEmployee.setPassword(employee.getPassword());
       

        employerService.updateEmployee(currentEmployee);
        return new ResponseEntity<Employee>(currentEmployee, HttpStatus.OK);
    }

    @DeleteMapping("/employees/{persinfoid}")
    public ResponseEntity<Employee> deleteUser(@PathVariable("persinfoid") int persinfoid) {
        System.out.println("Fetching & Deleting Employee with id " + persinfoid);

        Employee employer = employerService.viewOneEmployee(persinfoid);
        if (employer == null) {
            System.out.println("Unable to delete. Employee with id " + persinfoid + " not found");
            return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
        }

        employerService.deleteEmployee(persinfoid);
        return new ResponseEntity<Employee>(HttpStatus.NO_CONTENT);
    }

}
