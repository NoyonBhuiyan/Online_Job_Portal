
package com.job.jobboard.service;

import com.job.jobboard.model.Jobpost;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface JobpostService {

    public Jobpost insertJobpost(Jobpost jobpost);

    public void updateJobpost(Jobpost jobpost);

    public void deleteJobpost(int jobpostid);

    public List<Jobpost>viewJobpost();

    public Jobpost viewOneJobpost(int jobpostid);

   public List<Jobpost>viewJobpostcat(String jcat);

}
