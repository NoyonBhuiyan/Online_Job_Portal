
package com.job.jobboard.service;

import com.job.jobboard.model.City;
import com.job.jobboard.model.CompanyCategory;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface CompanyCategoryService {
    public CompanyCategory insertCompanyCategory(CompanyCategory cm);

    public void updateCompanyCategory(CompanyCategory cm);

    public void deleteCompanyCategory(int comcatid);

    public List<CompanyCategory> viewCompanyCategory();

    public CompanyCategory viewOneCompanyCategory(int comcatid);
}
