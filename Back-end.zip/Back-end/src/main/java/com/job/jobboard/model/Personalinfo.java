package com.job.jobboard.model;
// Generated Mar 9, 2020 3:41:41 PM by Hibernate Tools 4.3.1


import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Int;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


public class Personalinfo  implements java.io.Serializable {

     @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
      @Column
     private int persinfoid;
      @Column
     private String emailid;
       @Column
    private String firstname;
    @Column
    private String lastname;
    @Column
    private String fathername;
    @Column
    private String mothername;
    @Column
    private String dofbirth;
    @Column
    private String presaddress;
    @Column
    private String permaddress;
    @Column
    private String meritialstatus;
    @Column
    private String gender;
    @Column
    private String religion;
    @Column
    private String nationality;
    @Column
    private String email;
    @Column
    private String phone;
    @Column
    private String empstatus;
    @Column
    private String imgurl;

   
   
    public int getPersinfoid() {
        return this.persinfoid;
    }
    
    public void setPersinfoid(int persinfoid) {
        this.persinfoid = persinfoid;
    }
    public String getEmailid() {
        return this.emailid;
    }
    
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }
    public String getFirstname() {
        return this.firstname;
    }
    
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getLastname() {
        return this.lastname;
    }
    
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getFathername() {
        return this.fathername;
    }
    
    public void setFathername(String fathername) {
        this.fathername = fathername;
    }
    public String getMothername() {
        return this.mothername;
    }
    
    public void setMothername(String mothername) {
        this.mothername = mothername;
    }
    public String getDofbirth() {
        return this.dofbirth;
    }
    
    public void setDofbirth(String dofbirth) {
        this.dofbirth = dofbirth;
    }
    public String getPresaddress() {
        return this.presaddress;
    }
    
    public void setPresaddress(String presaddress) {
        this.presaddress = presaddress;
    }
    public String getPermaddress() {
        return this.permaddress;
    }
    
    public void setPermaddress(String permaddress) {
        this.permaddress = permaddress;
    }
    public String getMeritialstatus() {
        return this.meritialstatus;
    }
    
    public void setMeritialstatus(String meritialstatus) {
        this.meritialstatus = meritialstatus;
    }
    public String getGender() {
        return this.gender;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getReligion() {
        return this.religion;
    }
    
    public void setReligion(String religion) {
        this.religion = religion;
    }
    public String getNationality() {
        return this.nationality;
    }
    
    public void setNationality(String nationality) {
        this.nationality = nationality;
    }
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPhone() {
        return this.phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getEmpstatus() {
        return this.empstatus;
    }
    
    public void setEmpstatus(String empstatus) {
        this.empstatus = empstatus;
    }
    public String getImgurl() {
        return this.imgurl;
    }
    
    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }




}


