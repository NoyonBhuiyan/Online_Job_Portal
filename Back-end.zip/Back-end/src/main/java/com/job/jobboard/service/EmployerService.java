package com.job.jobboard.service;

import com.job.jobboard.model.Employer;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface EmployerService {
    public Employer insertEmployer(Employer cm);

    public void updateEmployer(Employer empid);

    public void deleteEmployer(int empid);

    public List<Employer> viewEmployer();

    public Employer viewOneEmployer(int empid);
}
