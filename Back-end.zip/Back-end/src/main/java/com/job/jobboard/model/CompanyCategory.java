
package com.job.jobboard.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class CompanyCategory implements Serializable {

    @Id
    @GeneratedValue()
    private int comcatid;
    @Column
    String comcatname;

    public int getComcatid() {
        return comcatid;
    }

    public void setComcatid(int comcatid) {
        this.comcatid = comcatid;
    }

    public String getComcatname() {
        return comcatname;
    }

    public void setComcatname(String comcatname) {
        this.comcatname = comcatname;
    }

}
