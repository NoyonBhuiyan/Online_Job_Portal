package com.job.jobboard.service;

import com.job.jobboard.model.Employee;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface EmployeeService {
    public Employee insertEmployee(Employee cm);

    public void updateEmployee(Employee cm);

    public void deleteEmployee(int persinfoid);

    public List<Employee> getAllEmployee();

    public Employee viewOneEmployee(int persinfoid);
}
