/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.job.jobboard.repository;

import com.job.jobboard.model.Employee;
import com.job.jobboard.service.EmployeeService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class EmployeeRepository implements EmployeeService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Employee insertEmployee(Employee cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(cm);
        t.commit();
        s.close();
        return cm;
    }

    @Override
    public void updateEmployee(Employee cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(cm);
        t.commit();
        s.close();
    }

    @Override
    public void deleteEmployee(int persinfoid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Employee cm = (Employee) s.get(Employee.class, persinfoid);
        s.delete(cm);
        t.commit();
        s.close();
    }

    @Override
    public List<Employee> getAllEmployee() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Employee> arealist = s.createQuery("from Employee").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return arealist;
    }

    @Override
    public Employee viewOneEmployee(int persinfoid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Employee cm = (Employee) s.get(Employee.class, persinfoid);
        t.commit();
        s.close();
        return cm;
    }

    
    
}
