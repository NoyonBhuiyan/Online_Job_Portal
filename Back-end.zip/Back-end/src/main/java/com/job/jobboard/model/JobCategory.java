/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.job.jobboard.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author USER
 */
@Entity
public class JobCategory implements Serializable {

    @Id
     @GeneratedValue(strategy = GenerationType.AUTO)
    private int jobcatid;
    @Column
    String jobcatname;

    public int getJobcatid() {
        return jobcatid;
    }

    public void setJobcatid(int jobcatid) {
        this.jobcatid = jobcatid;
    }

    public String getJobcatname() {
        return jobcatname;
    }

    public void setJobcatname(String jobcatname) {
        this.jobcatname = jobcatname;
    }

}
