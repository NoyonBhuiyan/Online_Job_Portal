
package com.job.jobboard.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Employee  implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
     private int persinfoid;
    @Column
     private String username;
    @Column
     private String gender;
    @Column
     private String emailid;
    @Column
     private String phone;
    @Column
     private String password;
    
  

    public int getPersinfoid() {
        return persinfoid;
    }

    public void setPersinfoid(int persinfoid) {
        this.persinfoid = persinfoid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
   
   


}
