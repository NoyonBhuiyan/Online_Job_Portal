
package com.job.jobboard.repository;

import com.google.gson.Gson;
import com.job.jobboard.service.EducationalinfoService;
import com.job.jobboard.model.Educationalinfo;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class EducationalinfoRepository implements EducationalinfoService{
    
@Autowired
    SessionFactory sessionFactory;

    @Override
    public Educationalinfo insertEducationalinfo(Educationalinfo educationalinfo) {
      Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(educationalinfo);
        t.commit();
        s.close();
        return null;
    }

    @Override
    public void updateEducationalinfo(Educationalinfo educationalinfo) {
      Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
//        Educationalinfo oneeducationalinfoobject = (Educationalinfo) s.get(Educationalinfo.class, eduid);
//        oneeducationalinfoobject.setEduid(oneeducationalinfoobject.getEduid());
//        oneeducationalinfoobject.setPersinfoid(oneeducationalinfoobject.getPersinfoid());
//        oneeducationalinfoobject.setEdulavel(oneeducationalinfoobject.getEdulavel());
//        oneeducationalinfoobject.setEdutitle(oneeducationalinfoobject.getEdutitle());
//        oneeducationalinfoobject.setInstitutename(oneeducationalinfoobject.getInstitutename());
//        oneeducationalinfoobject.setMajorgroup(oneeducationalinfoobject.getMajorgroup());
//        oneeducationalinfoobject.setPassingyear(oneeducationalinfoobject.getPassingyear());
//        oneeducationalinfoobject.setResult(oneeducationalinfoobject.getResult());
       
        s.update(educationalinfo);
        t.commit();
        s.close();
        
    }

    @Override
    public void deleteEducationalinfo(int eduid) {
       Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Educationalinfo educationalinfo = (Educationalinfo) s.get(Educationalinfo.class, eduid);
        s.delete(educationalinfo);
        t.commit();
        s.close();
        
    }

    @Override
    public List<Educationalinfo> viewEducationalinfo() {
     Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Educationalinfo> educationalinfolist = s.createQuery("from Educationalinfo").list();
//        Gson g = new Gson();
//        String educationalinfolistlistgson = g.toJson(educationalinfolist);
        t.commit();
        s.close();
        return educationalinfolist;  
    }

    @Override
    public Educationalinfo viewOneEducationalinfo(int eduid) {
       Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Educationalinfo educationalinfo = (Educationalinfo) s.get(Educationalinfo.class, eduid);
        t.commit();
        s.close();
        return educationalinfo;
    }
    
}
