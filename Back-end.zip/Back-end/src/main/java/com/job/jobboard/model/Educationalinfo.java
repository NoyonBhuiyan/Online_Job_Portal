
package com.job.jobboard.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
public class Educationalinfo implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int eduid;
    @Column
    private String persinfoid;
    @Column
    private String edulavel;
    @Column
    private String edutitle;
    @Column
    private String institutename;
    @Column
    private String majorgroup;
     @Column
    private String passingyear;
    @Column
    private String result;
    

    public int getEduid() {
        return eduid;
    }

    public void setEduid(int eduid) {
        this.eduid = eduid;
    }

    public String getPersinfoid() {
        return persinfoid;
    }

    public void setPersinfoid(String persinfoid) {
        this.persinfoid = persinfoid;
    }

   

    public String getEdulavel() {
        return edulavel;
    }

    public void setEdulavel(String edulavel) {
        this.edulavel = edulavel;
    }

    public String getEdutitle() {
        return edutitle;
    }

    public void setEdutitle(String edutitle) {
        this.edutitle = edutitle;
    }

    public String getInstitutename() {
        return institutename;
    }

    public void setInstitutename(String institutename) {
        this.institutename = institutename;
    }

    public String getMajorgroup() {
        return majorgroup;
    }

    public void setMajorgroup(String majorgroup) {
        this.majorgroup = majorgroup;
    }

    public String getPassingyear() {
        return passingyear;
    }

    public void setPassingyear(String passingyear) {
        this.passingyear = passingyear;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

   
    
    

}
