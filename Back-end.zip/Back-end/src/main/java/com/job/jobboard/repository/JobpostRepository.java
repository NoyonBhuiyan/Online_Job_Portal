
package com.job.jobboard.repository;

import com.google.gson.Gson;
import com.job.jobboard.service.JobpostService;
import com.job.jobboard.model.Jobpost;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author B10
 */
@Repository
public class JobpostRepository implements JobpostService{
    
    @Autowired
    SessionFactory sessionFactory;

    @Override
    public Jobpost insertJobpost(Jobpost jobpost) {
      Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(jobpost);
        t.commit();
        s.close();
        return null;  
    }
    @Override
    public void updateJobpost(Jobpost jobpost) {
      Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
//        Jobpost oneemphistoryobject = (Jobpost) s.get(Jobpost.class, emphisid);
// 
//        oneemphistoryobject.setComcatid(emphistory.getComcatid());
//        oneemphistoryobject.setComcatname(emphistory.getComcatname());
//    
//       
//        oneemphistoryobject.setPosition(emphistory.getPosition());
//        oneemphistoryobject.setRespons(emphistory.getRespons());
//        oneemphistoryobject.setFromdate(emphistory.getFromdate());
//        oneemphistoryobject.setTodate(emphistory.getTodate());      
        s.update(jobpost);
        t.commit();
        s.close();
       
    }

    @Override
    public void deleteJobpost(int jobpostid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Jobpost jobpost = (Jobpost) s.get(Jobpost.class, jobpostid);
        s.delete(jobpost);
        t.commit();
        s.close();
        
    }

    @Override
    public List<Jobpost> viewJobpost() {
       Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Jobpost> jobpostlist = s.createQuery("from Jobpost").list();
//        Gson g = new Gson();
//        String emphistorylistlistgson = g.toJson(emphistorylist);
        t.commit();
        s.close();
        return jobpostlist;
    }

    @Override
    public Jobpost viewOneJobpost(int jobpostid) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Jobpost jobpost = (Jobpost) s.get(Jobpost.class, jobpostid);
        t.commit();
        s.close();
        return jobpost;
    }
    
    
   @Override
    public List<Jobpost> viewJobpostcat(String jcat) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Query query = s.createQuery("from Jobpost r where r.jobcatname like concat('%',:sor,'%') or r.edureq like concat('%',:sor,'%') or r.jobtitle like concat('%',:sor,'%')or r.joblocation like concat('%',:sor,'%')or r.skillreq like concat('%',:sor,'%')or r.jobnature like concat('%',:sor,'%')or r.experencereq like concat('%',:sor,'%')or r.jobpoststatus like concat('%',:sor,'%')or r.basicreqm like concat('%',:sor,'%')or r.comname like concat('%',:sor,'%')or r.additionalreq like concat('%',:sor,'%')or r.otherbenifit like concat('%',:sor,'%')");
        query.setParameter("sor", jcat);
       
        List<Jobpost> rf = (List<Jobpost>)query.list();
        t.commit();
        s.close();
        return rf;
    }  
    
    
}
    
    
//     @Override
//    public List<Jobpost> viewJobpostCat() {
//       Session s = sessionFactory.openSession();
//        Transaction t = s.getTransaction();
//        t.begin();
//        List<Jobpost> jobpostlist = s.createQuery("from Jobpost").list();
////        Gson g = new Gson();
////        String emphistorylistlistgson = g.toJson(emphistorylist);
//        t.commit();
//        s.close();
//        return jobpostlist;
//    }
//    

