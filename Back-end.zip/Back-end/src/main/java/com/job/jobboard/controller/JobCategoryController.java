/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.job.jobboard.controller;


import  com.job.jobboard.service.JobCategoryService;
import  com.job.jobboard.model.JobCategory;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author USER
 */
@RestController
@RequestMapping(value = "/api/v1")
public class JobCategoryController {
    
    @Autowired
    private JobCategoryService jobcat;
    
    
    @GetMapping("/jobcategory")
    public List<JobCategory> getAllJobCategory() {
        return jobcat.viewJobCategory();
    }

    @PostMapping("/jobcategory")
    public JobCategory createJobCategory(@RequestBody JobCategory jobcategory) {
        return jobcat.insertJobCategory(jobcategory);
    }

    @GetMapping("/jobcategory/{jobcatid}")
    public ResponseEntity<JobCategory> getUser(@PathVariable("jobcatid") int jobcatid) {
        System.out.println("Fetching User with id " + jobcatid);
        JobCategory jobcategory = jobcat.viewOneJobCategory(jobcatid);
        if (jobcategory == null) {
            System.out.println("City with id " + jobcatid + " not found");
            return new ResponseEntity<JobCategory>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<JobCategory>(jobcategory, HttpStatus.OK);
    }

    @PutMapping("/jobcategory/{jobcatid}")
    public ResponseEntity<JobCategory> updateUser(@PathVariable("jobcatid") int jobcatid, @RequestBody JobCategory jobcategory) {
        System.out.println("Updating City " + jobcatid);

        JobCategory currentJobCategory = jobcat.viewOneJobCategory(jobcatid);

        if (currentJobCategory == null) {
            System.out.println("User with id " + jobcatid + " not found");
            return new ResponseEntity<JobCategory>(HttpStatus.NOT_FOUND);
        }

        currentJobCategory.setJobcatname(jobcategory.getJobcatname());
        currentJobCategory.setJobcatid(jobcategory.getJobcatid());

       jobcat.updateJobCategory(currentJobCategory);
        return new ResponseEntity<JobCategory>(currentJobCategory, HttpStatus.OK);
    }

    @DeleteMapping("/jobcategory/{jobcatid}")
    public ResponseEntity<JobCategory> deleteUser(@PathVariable("jobcatid") int jobcatid) {
        System.out.println("Fetching & Deleting City with id " + jobcatid);

        JobCategory jobcategory = jobcat.viewOneJobCategory(jobcatid);
        if (jobcategory == null) {
            System.out.println("Unable to delete. JobCategory with id " + jobcatid + " not found");
            return new ResponseEntity<JobCategory>(HttpStatus.NOT_FOUND);
        }

        jobcat.deleteJobCategory(jobcatid);
        return new ResponseEntity<JobCategory>(HttpStatus.NO_CONTENT);
    }

}

    
    
    
//    @RequestMapping("/showingjobcategorypage")
//    public ModelAndView showjobcatpage() {
//        String jobcategorygsonlist = jobcat.viewJobCategory();
//        ModelAndView mv = new ModelAndView("addjobcategory", "addJobCategoryObject1", new JobCategory());
//        mv.addObject("jobcategorymodelobject", jobcategorygsonlist);
//        mv.addObject("check", "true");
//        return mv;
//    }
//    
//    @RequestMapping(value = "/addingjobcategory", params = "Addjobcategory")
//    public String addjobcategory(@ModelAttribute("addJobCategoryObject1") JobCategory jc) {
//        //String jobcategorygsonlist = cdao.viewJobCategory();
//        //ModelAndView mv =new ModelAndView("AddJobCategory");
//        jobcat.insertJobCategory(jc);
//        //mv.addObject("jobcategorymodelobject", jobcategorygsonlist);
//        return "redirect:/showingjobcategorypage";
//    }
//    
//    @RequestMapping(value = "/addingjobcategory", params = "EditJobCategory")
//    public String editjobcategory(@ModelAttribute("addJobCategoryObject1") JobCategory jc) {
//
//        //ModelAndView mv =new ModelAndView("AddCategory");
//        jobcat.updateJobCategory(jc);
//        return "redirect:/showingjobcategorypage";
//    }
//    
//     @RequestMapping("removejobcategory/{Id}")
//    public String removejobcategory(@PathVariable("Id") String jobcategoryId) {
//        jobcat.deleteJobCategory(jobcategoryId);
//        return "redirect:/showingjobcategorypage";
//    }
//    
//    @RequestMapping("/editjobcategorybutton")
//    public ModelAndView passingonejobcategory(@RequestParam("getjcid") String jobcategoryId) {
//
//        JobCategory onejobcategory = jobcat.viewOneJobCategory(jobcategoryId);
//        String jobcategorygsonlist = jobcat.viewJobCategory();
//        ModelAndView mv = new ModelAndView("addjobcategory", "addJobCategoryObject1", onejobcategory);
//        mv.addObject("jobcategorymodelobject", jobcategorygsonlist);
//        mv.addObject("check", "false");
//        return mv;
//    }
//    
//}
