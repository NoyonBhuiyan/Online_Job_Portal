package com.job.jobboard.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Jobapplied implements java.io.Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int applyid;
    @Column
    private String persinfoid;
    @Column
    private String jobpostid;
    @Column
    private String coverletter;
    @Column
    private String expectsalary;
    @Column
    private String applydate;
    @Column
    private String applystatus;

  

    public int getApplyid() {
        return this.applyid;
    }

    public void setApplyid(int applyid) {
        this.applyid = applyid;
    }

    public String getPersinfoid() {
        return this.persinfoid;
    }

    public void setPersinfoid(String persinfoid) {
        this.persinfoid = persinfoid;
    }

    public String getJobpostid() {
        return this.jobpostid;
    }

    public void setJobpostid(String jobpostid) {
        this.jobpostid = jobpostid;
    }

    public String getCoverletter() {
        return this.coverletter;
    }

    public void setCoverletter(String coverletter) {
        this.coverletter = coverletter;
    }

    public String getExpectsalary() {
        return this.expectsalary;
    }

    public void setExpectsalary(String expectsalary) {
        this.expectsalary = expectsalary;
    }

    public String getApplydate() {
        return applydate;
    }

    public void setApplydate(String applydate) {
        this.applydate = applydate;
    }

    

    public String getApplystatus() {
        return this.applystatus;
    }

    public void setApplystatus(String applystatus) {
        this.applystatus = applystatus;
    }

}
