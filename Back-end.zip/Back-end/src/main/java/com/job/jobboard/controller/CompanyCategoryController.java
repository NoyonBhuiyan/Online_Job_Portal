package com.job.jobboard.controller;

import com.job.jobboard.model.CompanyCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.job.jobboard.service.CompanyCategoryService;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/v1")
public class CompanyCategoryController {

    @Autowired
    CompanyCategoryService comcat;

    @GetMapping("/companycategory")
    public List<CompanyCategory> getAllCompanyCategory() {
        return comcat.viewCompanyCategory();
    }

    @PostMapping("/companycategory")
    public CompanyCategory createCompanyCategory(@RequestBody CompanyCategory companycategory) {
        return comcat.insertCompanyCategory(companycategory);
    }

    @GetMapping("/companycategory/{comcatid}")
    public ResponseEntity<CompanyCategory> getUser(@PathVariable("comcatid") int comcatid) {
        System.out.println("Fetching User with id " + comcatid);
        CompanyCategory companycategory = comcat.viewOneCompanyCategory(comcatid);
        if (companycategory == null) {
            System.out.println("CompanyCategory with id " + comcatid + " not found");
            return new ResponseEntity<CompanyCategory>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<CompanyCategory>(companycategory, HttpStatus.OK);
    }

    @PutMapping("/companycategory/{comcatid}")
    public ResponseEntity<CompanyCategory> updateUser(@PathVariable("comcatid") int comcatid, @RequestBody CompanyCategory companycategory) {
        System.out.println("Updating CompanyCategory " + comcatid);

        CompanyCategory currentCompanyCategory = comcat.viewOneCompanyCategory(comcatid);

        if (currentCompanyCategory == null) {
            System.out.println("User with id " + comcatid + " not found");
            return new ResponseEntity<CompanyCategory>(HttpStatus.NOT_FOUND);
        }

        currentCompanyCategory.setComcatname(companycategory.getComcatname());

        currentCompanyCategory.setComcatid(companycategory.getComcatid());

        comcat.updateCompanyCategory(currentCompanyCategory);
        return new ResponseEntity<CompanyCategory>(currentCompanyCategory, HttpStatus.OK);
    }

    @DeleteMapping("/companycategory/{comcatid}")
    public ResponseEntity<CompanyCategory> deleteUser(@PathVariable("comcatid") int comcatid) {
        System.out.println("Fetching & Deleting CompanyCategory with id " + comcatid);

        CompanyCategory companycategory = comcat.viewOneCompanyCategory(comcatid);
        if (companycategory == null) {
            System.out.println("Unable to delete. CompanyCategory with id " + comcatid + " not found");
            return new ResponseEntity<CompanyCategory>(HttpStatus.NOT_FOUND);
        }

        comcat.deleteCompanyCategory(comcatid);
        return new ResponseEntity<CompanyCategory>(HttpStatus.NO_CONTENT);
    }

}

//    @RequestMapping("/showingcompanycategorypage")
//    public ModelAndView showcomcatpage() {
//        String companycategorygsonlist = comcat.viewCompanyCategory();
//        ModelAndView mv = new ModelAndView("addcompanycategory", "addCompanyCategoryObject1", new CompanyCategory());
//        mv.addObject("companycategorymodelobject", companycategorygsonlist);
//        mv.addObject("check", "true");
//        return mv;
//    }
//
//    @RequestMapping(value = "/addingcompanycategory", params = "Addcompanycategory")
//    public String addcompanycategory(@ModelAttribute("addCompanyCategoryObject1") CompanyCategory cm) {
//        //String categorygsonlist = cdao.viewCategory();
//        //ModelAndView mv =new ModelAndView("AddCategory");
//        comcat.insertCompanyCategory(cm);
//        //mv.addObject("categorymodelobject", categorygsonlist);
//        return "redirect:/showingcompanycategorypage";
//    }
//
//    @RequestMapping(value = "/addingcompanycategory", params = "EditCompanyCategory")
//    public String editcompanycategory(@ModelAttribute("addCompanyCategoryObject1") CompanyCategory cm) {
//
//        //ModelAndView mv =new ModelAndView("AddCategory");
//        comcat.updateCompanyCategory(cm);
//        return "redirect:/showingcompanycategorypage";
//    }
//
//    @RequestMapping("removecompanycategory/{Id}")
//    public String removecompanycategory(@PathVariable("Id") String companycategoryId) {
//        comcat.deleteCompanyCategory(companycategoryId);
//        return "redirect:/showingcompanycategorypage";
//    }
//
//    @RequestMapping("/editcompanycategorybutton")
//    public ModelAndView passingonecompanycategory(@RequestParam("getcid") String companycategoryId) {
//
//        CompanyCategory onecompanycategory = comcat.viewOneCompanyCategory(companycategoryId);
//        String companycategorygsonlist = comcat.viewCompanyCategory();
//        ModelAndView mv = new ModelAndView("addcompanycategory", "addCompanyCategoryObject1", onecompanycategory);
//        mv.addObject("companycategorymodelobject", companycategorygsonlist);
//        mv.addObject("check", "false");
//        return mv;
//    }
//}
