/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.job.jobboard.repository;

import com.job.jobboard.model.Employer;
import com.job.jobboard.service.EmployerService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class EmployerRepository implements EmployerService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Employer insertEmployer(Employer cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(cm);
        t.commit();
        s.close();
        return cm;
    }

    @Override
    public void updateEmployer(Employer empid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(empid);
        t.commit();
        s.close();
    }

    @Override
    public void deleteEmployer(int empid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Employer cm = (Employer) s.get(Employer.class, empid);
        s.delete(cm);
        t.commit();
        s.close();
    }

    @Override
    public List<Employer> viewEmployer() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Employer> arealist = s.createQuery("from Employer").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return arealist;
    }

    @Override
    public Employer viewOneEmployer(int empid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Employer cm = (Employer) s.get(Employer.class, empid);
        t.commit();
        s.close();
        return cm;
    }

    
    
}
