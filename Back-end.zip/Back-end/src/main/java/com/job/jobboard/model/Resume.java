package com.job.jobboard.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Resume implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer persinfoid;
    @Column
    private String objective;
    @Column
    private String comname;
    @Column
    private String role;
    @Column
    private String startdate;
    @Column
    private String enddate;
    @Column
    private String compost;
    @Column
    private String fname;
    @Column
    private String lname;
    @Column
    private String faname;
    @Column
    private String moname;
    @Column
    private String dob;
    @Column
    private String gender;
    @Column
    private String religion;
    @Column
    private String nationality;
    @Column
    private String maritul;
    @Column
    private String email;
    @Column
    private String preaddress;
    @Column
    private String peraddress;
    @Column
    private String phone;
    @Column
    private String degreeone;
    @Column
    private String instituteone;
    @Column
    private String subjectone;
    @Column
    private String passone;
    @Column
    private String resultone;
    @Column
    private String degreetwo;
    @Column
    private String institutetwo;
    @Column
    private String subjecttwo;
    @Column
    private String passtwo;
    @Column
    private String resulttwo;
    @Column
    private String degreethree;
    @Column
    private String institutethree;
    @Column
    private String subjectthree;
    @Column
    private String passthree;
    @Column
    private String resultthree;
    @Column
    private String degreefour;
    @Column
    private String institutefour;
    @Column
    private String subjectfour;
    @Column
    private String passfour;
    @Column
    private String resultfour;
    @Column
    private byte[] imgurl;
    @Column
    private String skills;

    public Resume() {
    }

    public Resume(String objective, String comname, String role, String startdate, String enddate, String compost, String fname, String lname, String faname, String moname, String dob, String gender, String religion, String nationality, String maritul, String email, String preaddress, String peraddress, String phone, String degreeone, String instituteone, String subjectone, String passone, String resultone, String degreetwo, String institutetwo, String subjecttwo, String passtwo, String resulttwo, String degreethree, String institutethree, String subjectthree, String passthree, String resultthree, String degreefour, String institutefour, String subjectfour, String passfour, String resultfour, byte[] imgurl) {
        this.objective = objective;
        this.comname = comname;
        this.role = role;
        this.startdate = startdate;
        this.enddate = enddate;
        this.compost = compost;
        this.fname = fname;
        this.lname = lname;
        this.faname = faname;
        this.moname = moname;
        this.dob = dob;
        this.gender = gender;
        this.religion = religion;
        this.nationality = nationality;
        this.maritul = maritul;
        this.email = email;
        this.preaddress = preaddress;
        this.peraddress = peraddress;
        this.phone = phone;
        this.degreeone = degreeone;
        this.instituteone = instituteone;
        this.subjectone = subjectone;
        this.passone = passone;
        this.resultone = resultone;
        this.degreetwo = degreetwo;
        this.institutetwo = institutetwo;
        this.subjecttwo = subjecttwo;
        this.passtwo = passtwo;
        this.resulttwo = resulttwo;
        this.degreethree = degreethree;
        this.institutethree = institutethree;
        this.subjectthree = subjectthree;
        this.passthree = passthree;
        this.resultthree = resultthree;
        this.degreefour = degreefour;
        this.institutefour = institutefour;
        this.subjectfour = subjectfour;
        this.passfour = passfour;
        this.resultfour = resultfour;
        this.imgurl = imgurl;
    }

    public Integer getPersinfoid() {
        return this.persinfoid;
    }

    public void setPersinfoid(Integer persinfoid) {
        this.persinfoid = persinfoid;
    }

    public String getObjective() {
        return this.objective;
    }

    public void setObjective(String objective) {
        this.objective = objective;
    }

    public String getComname() {
        return this.comname;
    }

    public void setComname(String comname) {
        this.comname = comname;
    }

    public String getRole() {
        return this.role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getStartdate() {
        return this.startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getEnddate() {
        return this.enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getCompost() {
        return this.compost;
    }

    public void setCompost(String compost) {
        this.compost = compost;
    }

    public String getFname() {
        return this.fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return this.lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getFaname() {
        return this.faname;
    }

    public void setFaname(String faname) {
        this.faname = faname;
    }

    public String getMoname() {
        return this.moname;
    }

    public void setMoname(String moname) {
        this.moname = moname;
    }

    public String getDob() {
        return this.dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getReligion() {
        return this.religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String getNationality() {
        return this.nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getMaritul() {
        return this.maritul;
    }

    public void setMaritul(String maritul) {
        this.maritul = maritul;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPreaddress() {
        return this.preaddress;
    }

    public void setPreaddress(String preaddress) {
        this.preaddress = preaddress;
    }

    public String getPeraddress() {
        return this.peraddress;
    }

    public void setPeraddress(String peraddress) {
        this.peraddress = peraddress;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDegreeone() {
        return this.degreeone;
    }

    public void setDegreeone(String degreeone) {
        this.degreeone = degreeone;
    }

    public String getInstituteone() {
        return this.instituteone;
    }

    public void setInstituteone(String instituteone) {
        this.instituteone = instituteone;
    }

    public String getSubjectone() {
        return this.subjectone;
    }

    public void setSubjectone(String subjectone) {
        this.subjectone = subjectone;
    }

    public String getPassone() {
        return this.passone;
    }

    public void setPassone(String passone) {
        this.passone = passone;
    }

    public String getResultone() {
        return this.resultone;
    }

    public void setResultone(String resultone) {
        this.resultone = resultone;
    }

    public String getDegreetwo() {
        return this.degreetwo;
    }

    public void setDegreetwo(String degreetwo) {
        this.degreetwo = degreetwo;
    }

    public String getInstitutetwo() {
        return this.institutetwo;
    }

    public void setInstitutetwo(String institutetwo) {
        this.institutetwo = institutetwo;
    }

    public String getSubjecttwo() {
        return this.subjecttwo;
    }

    public void setSubjecttwo(String subjecttwo) {
        this.subjecttwo = subjecttwo;
    }

    public String getPasstwo() {
        return this.passtwo;
    }

    public void setPasstwo(String passtwo) {
        this.passtwo = passtwo;
    }

    public String getResulttwo() {
        return this.resulttwo;
    }

    public void setResulttwo(String resulttwo) {
        this.resulttwo = resulttwo;
    }

    public String getDegreethree() {
        return this.degreethree;
    }

    public void setDegreethree(String degreethree) {
        this.degreethree = degreethree;
    }

    public String getInstitutethree() {
        return this.institutethree;
    }

    public void setInstitutethree(String institutethree) {
        this.institutethree = institutethree;
    }

    public String getSubjectthree() {
        return this.subjectthree;
    }

    public void setSubjectthree(String subjectthree) {
        this.subjectthree = subjectthree;
    }

    public String getPassthree() {
        return this.passthree;
    }

    public void setPassthree(String passthree) {
        this.passthree = passthree;
    }

    public String getResultthree() {
        return this.resultthree;
    }

    public void setResultthree(String resultthree) {
        this.resultthree = resultthree;
    }

    public String getDegreefour() {
        return this.degreefour;
    }

    public void setDegreefour(String degreefour) {
        this.degreefour = degreefour;
    }

    public String getInstitutefour() {
        return this.institutefour;
    }

    public void setInstitutefour(String institutefour) {
        this.institutefour = institutefour;
    }

    public String getSubjectfour() {
        return this.subjectfour;
    }

    public void setSubjectfour(String subjectfour) {
        this.subjectfour = subjectfour;
    }

    public String getPassfour() {
        return this.passfour;
    }

    public void setPassfour(String passfour) {
        this.passfour = passfour;
    }

    public String getResultfour() {
        return this.resultfour;
    }

    public void setResultfour(String resultfour) {
        this.resultfour = resultfour;
    }

    public byte[] getImgurl() {
        return this.imgurl;
    }

    public void setImgurl(byte[] imgurl) {
        this.imgurl = imgurl;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }
    

}
