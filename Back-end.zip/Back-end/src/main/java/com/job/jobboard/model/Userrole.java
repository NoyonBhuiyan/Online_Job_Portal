package com.job.jobboard.model;
// Generated Mar 9, 2020 3:41:41 PM by Hibernate Tools 4.3.1

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Userrole implements java.io.Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String emailid;
    @Column
    private String password;
    @Column
    private String role;
    @Column
    private String status;

//    public Userrole() {
//    }
//
//    public Userrole(String emailid) {
//        this.emailid = emailid;
//    }
//
//    public Userrole(String emailid, String password, String role, String status) {
//        this.emailid = emailid;
//        this.password = password;
//        this.role = role;
//        this.status = status;
//    }

    public String getEmailid() {
        return this.emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return this.role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
