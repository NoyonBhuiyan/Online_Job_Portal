
package com.job.jobboard.controller;

import com.job.jobboard.model. Employer;

import com.job.jobboard.service.EmployerService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(value = "/api/v1")
public class EmployerController {

    @Autowired
    private EmployerService employerService;

    @GetMapping("/employer")
    public List<Employer> getAllEmployer() {
        return employerService.viewEmployer();
    }

    @PostMapping("/employer")
    public Employer createEmployer(@RequestBody Employer employer) {
        return employerService.insertEmployer(employer);
    }

    @GetMapping("/employer/{empid}")
    public ResponseEntity<Employer> getUser(@PathVariable("empid") int empid) {
        System.out.println("Fetching User with id " + empid);
        Employer employer = employerService.viewOneEmployer(empid);
        if (employer == null) {
            System.out.println("Employer with id " + empid + " not found");
            return new ResponseEntity<Employer>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Employer>(employer, HttpStatus.OK);
    }

    @PutMapping("/employer/{empid}")
    public ResponseEntity<Employer> updateUser(@PathVariable("empid") int empid, @RequestBody Employer employer) {
        System.out.println("Updating Employer " + empid);

        Employer currentEmployer = employerService.viewOneEmployer(empid);

        if (currentEmployer == null) {
            System.out.println("User with id " + empid + " not found");
            return new ResponseEntity<Employer>(HttpStatus.NOT_FOUND);
        }

        
      
        currentEmployer.setAreaid(employer.getAreaid());
        currentEmployer.setCityid(employer.getCityid());
        currentEmployer.setComcatid(employer.getComcatid());
        currentEmployer.setComdetails(employer.getComdetails());
        currentEmployer.setComfax(employer.getComfax());
        currentEmployer.setComname(employer.getComname());
         currentEmployer.setUsername(employer.getUsername());
        currentEmployer.setComphone(employer.getComphone());
        currentEmployer.setComstatus(employer.getComstatus());
        currentEmployer.setComwebsite(employer.getComwebsite());
        currentEmployer.setContemail(employer.getContemail());
        currentEmployer.setContperson(employer.getContperson());
        currentEmployer.setEmailid(employer.getEmailid());
        currentEmployer.setEmpid(employer.getEmpid());
         currentEmployer.setPassword(employer.getPassword());

        employerService.updateEmployer(currentEmployer);
        return new ResponseEntity<Employer>(currentEmployer, HttpStatus.OK);
    }

    @DeleteMapping("/employer/{empid}")
    public ResponseEntity<Employer> deleteUser(@PathVariable("empid") int empid) {
        System.out.println("Fetching & Deleting Employer with id " + empid);

        Employer employer = employerService.viewOneEmployer(empid);
        if (employer == null) {
            System.out.println("Unable to delete. Employer with id " + empid + " not found");
            return new ResponseEntity<Employer>(HttpStatus.NOT_FOUND);
        }

        employerService.deleteEmployer(empid);
        return new ResponseEntity<Employer>(HttpStatus.NO_CONTENT);
    }

}
