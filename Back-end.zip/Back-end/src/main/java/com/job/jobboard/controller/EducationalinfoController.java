
package com.job.jobboard.controller;



import com.job.jobboard.service.EducationalinfoService;

import com.job.jobboard.model.Educationalinfo;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author USER
 */
@RestController
@RequestMapping(value = "/api/v1")
public class EducationalinfoController {
    @Autowired
    EducationalinfoService eduinfo;
    
    
//     @InitBinder
//    public void myInitBinder(WebDataBinder binder) {
//      
//        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
//        binder.registerCustomEditor(Date.class, "passingyear", new CustomDateEditor(format, false));
//
//    }
    
    @GetMapping("/education")
    public List< Educationalinfo> getAllEducationalinfo() {
        return eduinfo.viewEducationalinfo();
    }

    @PostMapping("/education")
    public Educationalinfo createEducationalinfo(@RequestBody Educationalinfo educationalinfo) {
        return eduinfo.insertEducationalinfo(educationalinfo);
    }

    @GetMapping("/education/{eduid}")
    public ResponseEntity<Educationalinfo> getUser(@PathVariable("eduid") int eduid) {
        System.out.println("Fetching User with id " + eduid);
        Educationalinfo educationalinfo = eduinfo.viewOneEducationalinfo(eduid);
        if (educationalinfo == null) {
            System.out.println("Educationalinfo with id " + eduid + " not found");
            return new ResponseEntity<Educationalinfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Educationalinfo>(educationalinfo, HttpStatus.OK);
    }

    @PutMapping("/education/{eduid}")
    public ResponseEntity<Educationalinfo> updateUser(@PathVariable("eduid") int eduid, @RequestBody Educationalinfo educationalinfo) {
        System.out.println("Updating Educationalinfo " + eduid);

        Educationalinfo currentEducationalinfo = eduinfo.viewOneEducationalinfo(eduid);

        if (currentEducationalinfo == null) {
            System.out.println("User with id " + eduid + " not found");
            return new ResponseEntity<Educationalinfo>(HttpStatus.NOT_FOUND);
        }

        currentEducationalinfo.setPersinfoid(educationalinfo.getPersinfoid());
      currentEducationalinfo.setEduid(educationalinfo.getEduid());
        currentEducationalinfo.setEdulavel(educationalinfo.getEdulavel());
        currentEducationalinfo.setEdutitle(educationalinfo.getEdutitle());
        currentEducationalinfo.setInstitutename(educationalinfo.getInstitutename());
        currentEducationalinfo.setMajorgroup(educationalinfo.getMajorgroup());
        currentEducationalinfo.setPassingyear(educationalinfo.getPassingyear());
        currentEducationalinfo.setResult(educationalinfo.getResult());

       eduinfo.updateEducationalinfo(currentEducationalinfo);
        return new ResponseEntity<Educationalinfo>(currentEducationalinfo, HttpStatus.OK);
    }

    @DeleteMapping("/education/{eduid}")
    public ResponseEntity<Educationalinfo> deleteUser(@PathVariable("eduid") int eduid) {
        System.out.println("Fetching & Deleting Educationalinfo with id " + eduid);

        Educationalinfo educationalinfo = eduinfo.viewOneEducationalinfo(eduid);
        if (educationalinfo == null) {
            System.out.println("Unable to delete. Educationalinfo with id " + eduid + " not found");
            return new ResponseEntity<Educationalinfo>(HttpStatus.NOT_FOUND);
        }

        eduinfo.deleteEducationalinfo(eduid);
        return new ResponseEntity<Educationalinfo>(HttpStatus.NO_CONTENT);
    }

    
    
    
    
}
    
//      @RequestMapping("/showeeducationalinfopage")
//    public ModelAndView showeducationalinfopage() {
//        String educationalinfolist = eduinfo.viewEducationalinfo();
//        String userlist = us.viewUsers();  
//        ModelAndView mv = new ModelAndView("addeducationalinfo", "educationalinfoObject", new Educationalinfo());
//        mv.addObject("educationalinfolists", educationalinfolist);
//        mv.addObject("userlists", userlist);      
//        mv.addObject("check", "true");
//        return mv;
//    }
//    
//    @RequestMapping(value = "/Educationalinfo", params = "Add")
//    public String addeducationalinfo(@ModelAttribute("educationalinfoObject") Educationalinfo eduid, HttpServletRequest request) {
//        eduinfo.insertEducationalinfo(eduid);
//
//        return "redirect:/showeeducationalinfopage";
//    }
//    
//     @RequestMapping(value = "/Educationalinfo", params = "Edit")
//    public String editeducationalinfo(@ModelAttribute("educationalinfoObject") Educationalinfo eduid, HttpServletRequest request) {
//        eduinfo.updateEducationalinfo(eduid.getEduid(), eduid);
//
//        return "redirect:/showeeducationalinfopage";
//    }
//    
//     @RequestMapping("removingeducationalinfo/{educainid}")
//    public String removeeducationalinfo(@PathVariable("educainid") int educainid) {
//        eduinfo.deleteEducationalinfo(educainid);
//        return "redirect:/showeeducationalinfopage";
//    }
//    
//     @RequestMapping("/editingeducationalinfo")
//    public ModelAndView editoneeducationalinfo(@RequestParam("geteducid") int educainid) {
//        String educationalinfolist = eduinfo.viewEducationalinfo();
//        String userlist = us.viewUsers();
//        ModelAndView mv = new ModelAndView("addeducationalinfo", "educationalinfoObject", eduinfo.viewOneEducationalinfo(educainid));
//        mv.addObject("educationalinfolists", educationalinfolist);
//        mv.addObject("userlists", userlist);
//        mv.addObject("check", "false");
//        return mv;
//    }
//}
