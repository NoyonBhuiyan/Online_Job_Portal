package com.job.jobboard.service;

import com.job.jobboard.model.Userrole;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface UserroleService {
    public Userrole insertUserrole(Userrole cm);

    public void updateUserrole(Userrole cm);

    public void deleteUserrole(String emailid);

    public List<Userrole> viewUserrole();

    public Userrole viewOneUserrole(String emailid);
}
