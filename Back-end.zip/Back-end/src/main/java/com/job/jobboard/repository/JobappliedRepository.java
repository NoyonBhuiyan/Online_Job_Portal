/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.job.jobboard.repository;

import com.job.jobboard.model.Jobapplied;
import com.job.jobboard.service.JobappliedService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class JobappliedRepository implements JobappliedService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Jobapplied insertJobapplied(Jobapplied cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(cm);
        t.commit();
        s.close();
        return cm;
    }

    @Override
    public void updateJobapplied(Jobapplied cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(cm);
        t.commit();
        s.close();
    }

    @Override
    public void deleteJobapplied(int areaid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Jobapplied cm = (Jobapplied) s.get(Jobapplied.class, areaid);
        s.delete(cm);
        t.commit();
        s.close();
    }

    @Override
    public List<Jobapplied> viewJobapplied() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Jobapplied> arealist = s.createQuery("from Jobapplied").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return arealist;
    }

    @Override
    public Jobapplied viewOneJobapplied(int areaid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Jobapplied cm = (Jobapplied) s.get(Jobapplied.class, areaid);
        t.commit();
        s.close();
        return cm;
    }

    
    
}
