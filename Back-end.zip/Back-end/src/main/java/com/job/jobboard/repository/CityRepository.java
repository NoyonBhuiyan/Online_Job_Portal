
package com.job.jobboard.repository;

import com.google.gson.Gson;
import com.job.jobboard.service.CityService;
import com.job.jobboard.model.City;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class CityRepository implements CityService {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public City insertCity(City c) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(c);
        t.commit();
        s.close();
        return null;
    }

    @Override
    public void updateCity( City c) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.update(c);
        t.commit();
        s.close();
        
    }

    @Override
    public void deleteCity(int cityid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        City c = (City) s.get(City.class, cityid);
        s.delete(c);
        t.commit();
        s.close();
        
    }

     @Override
    public List<City> viewCity() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<City> citylist = s.createQuery("from City").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return citylist;
    }
    @Override
    public City viewOneCity(int cityid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        City c = (City) s.get(City.class, cityid);
        t.commit();
        s.close();
        return c;
    }

   

}
