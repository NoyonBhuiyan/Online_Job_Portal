
package com.job.jobboard.controller;


import org.springframework.http.HttpStatus;
import com.job.jobboard.service.CityService;
import java.util.List;
import org.springframework.http.ResponseEntity;
import com.job.jobboard.model.City;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
@RequestMapping(value = "/api/v1")
public class CityController {

    @Autowired
    private CityService cs;
    
    @GetMapping("/city")
    public List<City> getAllCity() {
        return cs.viewCity();
    }

    @PostMapping("/city")
    public City createCity(@RequestBody City city) {
        return cs.insertCity(city);
    }

    @GetMapping("/city/{cityid}")
    public ResponseEntity<City> getUser(@PathVariable("cityid") int cityid) {
        System.out.println("Fetching User with id " + cityid);
        City city = cs.viewOneCity(cityid);
        if (city == null) {
            System.out.println("City with id " + cityid + " not found");
            return new ResponseEntity<City>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<City>(city, HttpStatus.OK);
    }

    @PutMapping("/city/{cityid}")
    public ResponseEntity<City> updateUser(@PathVariable("cityid") int cityid, @RequestBody City city) {
        System.out.println("Updating City " + cityid);

        City currentCity = cs.viewOneCity(cityid);

        if (currentCity == null) {
            System.out.println("User with id " + cityid + " not found");
            return new ResponseEntity<City>(HttpStatus.NOT_FOUND);
        }

        currentCity.setCityname(city.getCityname());
      
        currentCity.setCityid(city.getCityid());

       cs.updateCity(currentCity);
        return new ResponseEntity<City>(currentCity, HttpStatus.OK);
    }

    @DeleteMapping("/city/{cityid}")
    public ResponseEntity<City> deleteUser(@PathVariable("cityid") int cityid) {
        System.out.println("Fetching & Deleting City with id " + cityid);

        City city = cs.viewOneCity(cityid);
        if (city == null) {
            System.out.println("Unable to delete. City with id " + cityid + " not found");
            return new ResponseEntity<City>(HttpStatus.NOT_FOUND);
        }

        cs.deleteCity(cityid);
        return new ResponseEntity<City>(HttpStatus.NO_CONTENT);
    }

}

    
    
    
    
    
    
    
    
    

    //@Autowired
   // private ServletContext servletContext;

//    @RequestMapping("/showcitypage")
//    public ModelAndView showcity() {
//        String citylist = cs.viewCity();
//
//        ModelAndView mv = new ModelAndView("addcity", "newCityObject", new City());
//        mv.addObject("citylist", citylist);
//
//        mv.addObject("check", "true");
//        return mv;
//    }
//
//    @RequestMapping(value = "/cityadd", params = "Add")
//    public String addcitypage(@ModelAttribute("newCityObject") City city, HttpServletRequest request) {
//        cs.insertCity(city);
//
//        return "redirect:/showcitypage";
//    }
//
//    @RequestMapping(value = "/cityadd", params = "Edit")
//    public String editCity(@ModelAttribute("newCityObject") City city, HttpServletRequest request) {
//        cs.updateCity(city.getCity_id(), city);
//
//        return "redirect:/showcitypage";
//    }
//
//    @RequestMapping("removingcity/{cityId}")
//    public String removecity(@PathVariable("cityId") int city_id) {
//        cs.deleteCity(city_id);
//        return "redirect:/showcitypage";
//    }
//
//    @RequestMapping("/editingcity")
//    public ModelAndView editcitypage(@RequestParam("getcid") int pid) {
//        String citylist = cs.viewCity();
//
//        ModelAndView mv = new ModelAndView("addcity", "newCityObject", cs.viewOneCity(pid));
//        mv.addObject("citylist", citylist);
//
//        mv.addObject("check", "false");
//        return mv;
//    }
//}
