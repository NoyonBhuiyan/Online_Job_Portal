package com.job.jobboard.model;
// Generated Mar 9, 2020 3:41:41 PM by Hibernate Tools 4.3.1
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;






@Entity
public class Employer  implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
     private int empid;
    @Column
     private String username;
    @Column
     private String emailid;
    @Column
     private String comcatid;
    @Column
     private String areaid;
    @Column
     private String cityid;
    @Column
     private String comname;
    @Column
     private String contperson;
    @Column
     private String contemail;
    @Column
     private String comwebsite;
    @Column
     private String comdetails;
    @Column
     private String comphone;
    @Column
     private String comfax;
    @Column
     private String comstatus;
    @Column
     private String password;
   

	
   
   
    public int getEmpid() {
        return this.empid;
    }
    
    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public String getEmailid() {
        return this.emailid;
    }
    
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }
    public String getComcatid() {
        return this.comcatid;
    }
    
    public void setComcatid(String comcatid) {
        this.comcatid = comcatid;
    }
    public String getAreaid() {
        return this.areaid;
    }
    
    public void setAreaid(String areaid) {
        this.areaid = areaid;
    }
    public String getCityid() {
        return this.cityid;
    }
    
    public void setCityid(String cityid) {
        this.cityid = cityid;
    }
    public String getComname() {
        return this.comname;
    }
    
    public void setComname(String comname) {
        this.comname = comname;
    }
    public String getContperson() {
        return this.contperson;
    }
    
    public void setContperson(String contperson) {
        this.contperson = contperson;
    }
    public String getContemail() {
        return this.contemail;
    }
    
    public void setContemail(String contemail) {
        this.contemail = contemail;
    }
    public String getComwebsite() {
        return this.comwebsite;
    }
    
    public void setComwebsite(String comwebsite) {
        this.comwebsite = comwebsite;
    }
    public String getComdetails() {
        return this.comdetails;
    }
    
    public void setComdetails(String comdetails) {
        this.comdetails = comdetails;
    }
    public String getComphone() {
        return this.comphone;
    }
    
    public void setComphone(String comphone) {
        this.comphone = comphone;
    }
    public String getComfax() {
        return this.comfax;
    }
    
    public void setComfax(String comfax) {
        this.comfax = comfax;
    }
    public String getComstatus() {
        return this.comstatus;
    }
    
    public void setComstatus(String comstatus) {
        this.comstatus = comstatus;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }




}


