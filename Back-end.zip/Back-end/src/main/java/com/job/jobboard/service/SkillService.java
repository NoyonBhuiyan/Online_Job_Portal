
package com.job.jobboard.service;

import com.job.jobboard.model.Skill;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface SkillService {
    public Skill insertSkill(Skill cm);

    public void updateSkill(Skill cm);

    public void deleteSkill(int areaid);

    public List<Skill> viewSkill();

    public Skill viewOneSkill(int areaid);
}
