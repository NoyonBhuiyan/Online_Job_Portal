/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.job.jobboard.repository;

import com.job.jobboard.model.Resume;
import com.job.jobboard.service.ResumeService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class ResumeRepository implements ResumeService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Resume insertResume(Resume cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(cm);
        t.commit();
        s.close();
        return cm;
    }

    @Override
    public void updateResume(Resume cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(cm);
        t.commit();
        s.close();
    }

    @Override
    public void deleteResume(int persinfoid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Resume cm = (Resume) s.get(Resume.class, persinfoid);
        s.delete(cm);
        t.commit();
        s.close();
    }

    @Override
    public List<Resume> getAllResume() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Resume> arealist = s.createQuery("from Resume").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return arealist;
    }

    @Override
    public Resume viewOneResume(int persinfoid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Resume cm = (Resume) s.get(Resume.class, persinfoid);
        t.commit();
        s.close();
        return cm;
    }

    
    
}
