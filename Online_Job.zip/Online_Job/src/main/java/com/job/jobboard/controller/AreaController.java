
package com.job.jobboard.controller;

import com.job.jobboard.model. Area;

import com.job.jobboard.service.AreaService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/v1")
public class AreaController {

    @Autowired
    private AreaService areaService;

    @GetMapping("/area")
    public List<Area> getAllArea() {
        return areaService.viewArea();
    }

    @PostMapping("/area")
    public Area createArea(@RequestBody Area area) {
        return areaService.insertArea(area);
    }

    @GetMapping("/area/{areaid}")
    public ResponseEntity<Area> getUser(@PathVariable("areaid") int areaid) {
        System.out.println("Fetching User with id " + areaid);
        Area area = areaService.viewOneArea(areaid);
        if (area == null) {
            System.out.println("Area with id " + areaid + " not found");
            return new ResponseEntity<Area>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Area>(area, HttpStatus.OK);
    }

    @PutMapping("/area/{areaid}")
    public ResponseEntity<Area> updateUser(@PathVariable("areaid") int areaid, @RequestBody Area area) {
        System.out.println("Updating Area " + areaid);

        Area currentArea = areaService.viewOneArea(areaid);

        if (currentArea == null) {
            System.out.println("User with id " + areaid + " not found");
            return new ResponseEntity<Area>(HttpStatus.NOT_FOUND);
        }

        currentArea.setAreaname(area.getAreaname());
      
        currentArea.setAreaid(area.getAreaid());

        areaService.updateArea(currentArea);
        return new ResponseEntity<Area>(currentArea, HttpStatus.OK);
    }

    @DeleteMapping("/area/{areaid}")
    public ResponseEntity<Area> deleteUser(@PathVariable("areaid") int areaid) {
        System.out.println("Fetching & Deleting Area with id " + areaid);

        Area area = areaService.viewOneArea(areaid);
        if (area == null) {
            System.out.println("Unable to delete. Area with id " + areaid + " not found");
            return new ResponseEntity<Area>(HttpStatus.NOT_FOUND);
        }

        areaService.deleteArea(areaid);
        return new ResponseEntity<Area>(HttpStatus.NO_CONTENT);
    }

}
