package com.job.jobboard.model;
// Generated Mar 9, 2020 3:41:41 PM by Hibernate Tools 4.3.1

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Skill implements java.io.Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int skillid;
    @Column
    private String skillname;
    @Column
    private int persinfoid;

//    public Skill() {
//    }
//
//    public Skill(int persinfoid) {
//        this.persinfoid = persinfoid;
//    }
//
//    public Skill(String skillname, int persinfoid) {
//        this.skillname = skillname;
//        this.persinfoid = persinfoid;
//    }

    public Integer getSkillid() {
        return this.skillid;
    }

    public void setSkillid(Integer skillid) {
        this.skillid = skillid;
    }

    public String getSkillname() {
        return this.skillname;
    }

    public void setSkillname(String skillname) {
        this.skillname = skillname;
    }

    public int getPersinfoid() {
        return this.persinfoid;
    }

    public void setPersinfoid(int persinfoid) {
        this.persinfoid = persinfoid;
    }

}
