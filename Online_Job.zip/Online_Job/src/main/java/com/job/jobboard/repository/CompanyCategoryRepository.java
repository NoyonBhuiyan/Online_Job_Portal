package com.job.jobboard.repository;

import com.google.gson.Gson;
import com.job.jobboard.model.CompanyCategory;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.job.jobboard.service.CompanyCategoryService;

@Repository
public class CompanyCategoryRepository implements CompanyCategoryService {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public CompanyCategory insertCompanyCategory(CompanyCategory cm) {

        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(cm);
        t.commit();
        s.close();
        return null;
    }

    @Override
    public void updateCompanyCategory(CompanyCategory cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(cm);
        t.commit();
        s.close();

    }

    @Override
    public void deleteCompanyCategory(int comcatid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        CompanyCategory cm = (CompanyCategory) s.get(CompanyCategory.class, comcatid);
        s.delete(cm);
        t.commit();
        s.close();

    }

    @Override
    public List<CompanyCategory> viewCompanyCategory() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<CompanyCategory> companycategorieslist = s.createQuery("from CompanyCategory").list();
        Gson g = new Gson();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return companycategorieslist;
    }

    @Override
    public CompanyCategory viewOneCompanyCategory(int comcatid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        CompanyCategory cm = (CompanyCategory) s.get(CompanyCategory.class, comcatid);
        t.commit();
        s.close();
        return cm;
    }

}
