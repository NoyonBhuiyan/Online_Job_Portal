/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.job.jobboard.repository;

import com.job.jobboard.model.Userrole;
import com.job.jobboard.service.UserroleService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class UserroleRepository implements UserroleService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Userrole insertUserrole(Userrole cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(cm);
        t.commit();
        s.close();
        return cm;
    }

    @Override
    public void updateUserrole(Userrole cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(cm);
        t.commit();
        s.close();
    }

    @Override
    public void deleteUserrole(int areaid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Userrole cm = (Userrole) s.get(Userrole.class, areaid);
        s.delete(cm);
        t.commit();
        s.close();
    }

    @Override
    public List<Userrole> viewUserrole() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Userrole> arealist = s.createQuery("from Userrole").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return arealist;
    }

    @Override
    public Userrole viewOneUserrole(int areaid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Userrole cm = (Userrole) s.get(Userrole.class, areaid);
        t.commit();
        s.close();
        return cm;
    }

    
    
}
