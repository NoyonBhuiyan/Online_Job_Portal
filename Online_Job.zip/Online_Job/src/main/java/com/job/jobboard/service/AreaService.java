
package com.job.jobboard.service;

import com.job.jobboard.model.Area;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface AreaService {
    public Area insertArea(Area cm);

    public void updateArea(Area cm);

    public void deleteArea(int areaid);

    public List<Area> viewArea();

    public Area viewOneArea(int areaid);
}
