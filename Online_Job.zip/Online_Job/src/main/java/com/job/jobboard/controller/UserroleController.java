
package com.job.jobboard.controller;

import com.job.jobboard.model. Userrole;

import com.job.jobboard.service.UserroleService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/v1")
public class UserroleController {

    @Autowired
    private UserroleService areaService;

    @GetMapping("/userrole")
    public List<Userrole> getAllUserrole() {
        return areaService.viewUserrole();
    }

    @PostMapping("/userrole")
    public Userrole createUserrole(@RequestBody Userrole area) {
        return areaService.insertUserrole(area);
    }

    @GetMapping("/userrole/{emailid}")
    public ResponseEntity<Userrole> getUser(@PathVariable("areaid") int areaid) {
        System.out.println("Fetching User with id " + areaid);
        Userrole area = areaService.viewOneUserrole(areaid);
        if (area == null) {
            System.out.println("Userrole with id " + areaid + " not found");
            return new ResponseEntity<Userrole>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Userrole>(area, HttpStatus.OK);
    }

    @PutMapping("/userrole/{emailid}")
    public ResponseEntity<Userrole> updateUser(@PathVariable("areaid") int areaid, @RequestBody Userrole area) {
        System.out.println("Updating Userrole " + areaid);

        Userrole currentUserrole = areaService.viewOneUserrole(areaid);

        if (currentUserrole == null) {
            System.out.println("User with id " + areaid + " not found");
            return new ResponseEntity<Userrole>(HttpStatus.NOT_FOUND);
        }

        currentUserrole.setEmailid(area.getEmailid());
         currentUserrole.setPassword(area.getPassword());
          currentUserrole.setStatus(area.getStatus());
        currentUserrole.setRole(area.getRole());

        areaService.updateUserrole(currentUserrole);
        return new ResponseEntity<Userrole>(currentUserrole, HttpStatus.OK);
    }

    @DeleteMapping("/userrole/{emailid}")
    public ResponseEntity<Userrole> deleteUser(@PathVariable("areaid") int areaid) {
        System.out.println("Fetching & Deleting Userrole with id " + areaid);

        Userrole area = areaService.viewOneUserrole(areaid);
        if (area == null) {
            System.out.println("Unable to delete. Userrole with id " + areaid + " not found");
            return new ResponseEntity<Userrole>(HttpStatus.NOT_FOUND);
        }

        areaService.deleteUserrole(areaid);
        return new ResponseEntity<Userrole>(HttpStatus.NO_CONTENT);
    }

}
