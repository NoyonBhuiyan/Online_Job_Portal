
package com.job.jobboard.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
public class Emphistory implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int emphisid;

    @Column
    private int comcatid;
    @Column
    private String comcatname;

    @Column
    private String position;
    @Column
    private String respons;
    @Temporal(TemporalType.DATE)
    private Date fromdate;
    @Temporal(TemporalType.DATE)
    private Date todate;

    public int getEmphisid() {
        return emphisid;
    }

    public void setEmphisid(int emphisid) {
        this.emphisid = emphisid;
    }

    public int getComcatid() {
        return comcatid;
    }

    public void setComcatid(int comcatid) {
        this.comcatid = comcatid;
    }

    public String getComcatname() {
        return comcatname;
    }

    public void setComcatname(String comcatname) {
        this.comcatname = comcatname;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getRespons() {
        return respons;
    }

    public void setRespons(String respons) {
        this.respons = respons;
    }

    public Date getFromdate() {
        return fromdate;
    }

    public void setFromdate(Date fromdate) {
        this.fromdate = fromdate;
    }

    public Date getTodate() {
        return todate;
    }

    public void setTodate(Date todate) {
        this.todate = todate;
    }

}
