
package com.job.jobboard.service;

import com.job.jobboard.model.User;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface UserService {
    public User insertUser(User cm);

    public void updateUser(User cm);

    public void deleteUser(int areaid);

    public List<User> viewUser();

    public User viewOneUser(int areaid);
}
