
package com.job.jobboard.service;

import com.job.jobboard.model.Jobpost;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface JobpostService {

    public Jobpost insertJobpost(Jobpost emphistory);

    public void updateJobpost(Jobpost emphistory);

    public void deleteJobpost(int emphisid);

    public List<Jobpost>viewJobpost();

    public Jobpost viewOneJobpost(int emphisid);

}
