
package com.job.jobboard.controller;

import com.job.jobboard.model. Jobapplied;

import com.job.jobboard.service.JobappliedService;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/v1")
public class JobappliedController {

    @Autowired
    private JobappliedService areaService;
    
     @InitBinder
    public void myInitBinder(WebDataBinder binder) {
        //binder.setDisallowedFields(new String[]{"empMobile"});
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        binder.registerCustomEditor(Date.class, "applydate", new CustomDateEditor(format, false));
    }
    
    @GetMapping("/jobapplied")
    public List<Jobapplied> getAllJobapplied() {
        return areaService.viewJobapplied();
    }

    @PostMapping("/jobapplied")
    public Jobapplied createJobapplied(@RequestBody Jobapplied area) {
        return areaService.insertJobapplied(area);
    }

    @GetMapping("/jobapplied/{applyid}")
    public ResponseEntity<Jobapplied> getUser(@PathVariable("applyid") int areaid) {
        System.out.println("Fetching User with id " + areaid);
        Jobapplied area = areaService.viewOneJobapplied(areaid);
        if (area == null) {
            System.out.println("Jobapplied with id " + areaid + " not found");
            return new ResponseEntity<Jobapplied>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Jobapplied>(area, HttpStatus.OK);
    }

    @PutMapping("/jobapplied/{applyid}")
    public ResponseEntity<Jobapplied> updateUser(@PathVariable("applyid") int areaid, @RequestBody Jobapplied area) {
        System.out.println("Updating Jobapplied " + areaid);

        Jobapplied currentJobapplied = areaService.viewOneJobapplied(areaid);

        if (currentJobapplied == null) {
            System.out.println("User with id " + areaid + " not found");
            return new ResponseEntity<Jobapplied>(HttpStatus.NOT_FOUND);
        }

        currentJobapplied.setPersinfoid(area.getPersinfoid());
       currentJobapplied.setApplyid(area.getApplyid());
        currentJobapplied.setJobpostid(area.getJobpostid());
         currentJobapplied.setCoverletter(area.getCoverletter());
          currentJobapplied.setExpectsalary(area.getExpectsalary());
           currentJobapplied.setApplydate(area.getApplydate());
            currentJobapplied.setApplystatus(area.getApplystatus());

        areaService.updateJobapplied(currentJobapplied);
        return new ResponseEntity<Jobapplied>(currentJobapplied, HttpStatus.OK);
    }

    @DeleteMapping("/jobapplied/{applyid}")
    public ResponseEntity<Jobapplied> deleteUser(@PathVariable("applyid") int areaid) {
        System.out.println("Fetching & Deleting Jobapplied with id " + areaid);

        Jobapplied area = areaService.viewOneJobapplied(areaid);
        if (area == null) {
            System.out.println("Unable to delete. Jobapplied with id " + areaid + " not found");
            return new ResponseEntity<Jobapplied>(HttpStatus.NOT_FOUND);
        }

        areaService.deleteJobapplied(areaid);
        return new ResponseEntity<Jobapplied>(HttpStatus.NO_CONTENT);
    }

}
