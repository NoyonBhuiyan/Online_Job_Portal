package com.job.jobboard.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Jobapplied implements java.io.Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int applyid;
    @Column
    private int persinfoid;
    @Column
    private int jobpostid;
    @Column
    private String coverletter;
    @Column
    private String expectsalary;
    @Temporal(TemporalType.DATE)
    private Date applydate;
    @Column
    private String applystatus;

    public Jobapplied() {
    }

    public Jobapplied(int applyid, int persinfoid, int jobpostid, String coverletter, String expectsalary, Date applydate, String applystatus) {
        this.applyid = applyid;
        this.persinfoid = persinfoid;
        this.jobpostid = jobpostid;
        this.coverletter = coverletter;
        this.expectsalary = expectsalary;
        this.applydate = applydate;
        this.applystatus = applystatus;
    }

    public int getApplyid() {
        return this.applyid;
    }

    public void setApplyid(int applyid) {
        this.applyid = applyid;
    }

    public int getPersinfoid() {
        return this.persinfoid;
    }

    public void setPersinfoid(int persinfoid) {
        this.persinfoid = persinfoid;
    }

    public int getJobpostid() {
        return this.jobpostid;
    }

    public void setJobpostid(int jobpostid) {
        this.jobpostid = jobpostid;
    }

    public String getCoverletter() {
        return this.coverletter;
    }

    public void setCoverletter(String coverletter) {
        this.coverletter = coverletter;
    }

    public String getExpectsalary() {
        return this.expectsalary;
    }

    public void setExpectsalary(String expectsalary) {
        this.expectsalary = expectsalary;
    }

    public Date getApplydate() {
        return applydate;
    }

    public void setApplydate(Date applydate) {
        this.applydate = applydate;
    }

    

    public String getApplystatus() {
        return this.applystatus;
    }

    public void setApplystatus(String applystatus) {
        this.applystatus = applystatus;
    }

}
