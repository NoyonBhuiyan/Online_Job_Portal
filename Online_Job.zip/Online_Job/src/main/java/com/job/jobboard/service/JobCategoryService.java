
package com.job.jobboard.service;

import com.job.jobboard.model.JobCategory;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author USER
 */
@Service
public interface JobCategoryService {
     public JobCategory insertJobCategory(JobCategory jc);

    public void updateJobCategory(JobCategory jc);

    public void deleteJobCategory(int jobcatid);

    public List<JobCategory> viewJobCategory();

    public JobCategory viewOneJobCategory(int jobcatid);
    
}
