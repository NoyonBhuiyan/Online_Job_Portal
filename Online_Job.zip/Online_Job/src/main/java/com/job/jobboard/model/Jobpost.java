package com.job.jobboard.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Jobpost implements java.io.Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int jobpostid;
    @Column
    private int empid;
    @Column
    private String jobcatid;
    @Column
    private String jobtitle;
    @Column
    private String joblocation;
    @Column
    private String numofvacancy;
    @Temporal(TemporalType.DATE)
    private Date startdate;
    @Temporal(TemporalType.DATE)
    private Date enddate;
    @Column
    private String skillreq;
    @Column
    private String edureq;
    @Column
    private String basicreqm;
    @Column
    private String salaryrng;
    @Column
    private String jobnature;
    @Column
    private String experencereq;
    @Column
    private String jobpoststatus;
    @Column
    private String otherbenifit;
    @Column
    private String useremail;

   

//    public Jobpost(int empid, String jobcatid) {
//        this.empid = empid;
//        this.jobcatid = jobcatid;
//    }
//
//    public Jobpost(int empid, String jobcatid, String jobtitle, String joblocation, String numofvacancy, Date startdate, Date enddate, String skillreq, String edureq, String basicreqm, String salaryrng, String jobnature, String experencereq, String jobpoststatus, String otherbenifit, String useremail) {
//        this.empid = empid;
//        this.jobcatid = jobcatid;
//        this.jobtitle = jobtitle;
//        this.joblocation = joblocation;
//        this.numofvacancy = numofvacancy;
//        this.startdate = startdate;
//        this.enddate = enddate;
//        this.skillreq = skillreq;
//        this.edureq = edureq;
//        this.basicreqm = basicreqm;
//        this.salaryrng = salaryrng;
//        this.jobnature = jobnature;
//        this.experencereq = experencereq;
//        this.jobpoststatus = jobpoststatus;
//        this.otherbenifit = otherbenifit;
//        this.useremail = useremail;
//    }

    public Integer getJobpostid() {
        return this.jobpostid;
    }

    public void setJobpostid(Integer jobpostid) {
        this.jobpostid = jobpostid;
    }

    public int getEmpid() {
        return this.empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getJobcatid() {
        return this.jobcatid;
    }

    public void setJobcatid(String jobcatid) {
        this.jobcatid = jobcatid;
    }

    public String getJobtitle() {
        return this.jobtitle;
    }

    public void setJobtitle(String jobtitle) {
        this.jobtitle = jobtitle;
    }

    public String getJoblocation() {
        return this.joblocation;
    }

    public void setJoblocation(String joblocation) {
        this.joblocation = joblocation;
    }

    public String getNumofvacancy() {
        return this.numofvacancy;
    }

    public void setNumofvacancy(String numofvacancy) {
        this.numofvacancy = numofvacancy;
    }

    public Date getStartdate() {
        return startdate;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public Date getEnddate() {
        return enddate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    

    public String getSkillreq() {
        return this.skillreq;
    }

    public void setSkillreq(String skillreq) {
        this.skillreq = skillreq;
    }

    public String getEdureq() {
        return this.edureq;
    }

    public void setEdureq(String edureq) {
        this.edureq = edureq;
    }

    public String getBasicreqm() {
        return this.basicreqm;
    }

    public void setBasicreqm(String basicreqm) {
        this.basicreqm = basicreqm;
    }

    public String getSalaryrng() {
        return this.salaryrng;
    }

    public void setSalaryrng(String salaryrng) {
        this.salaryrng = salaryrng;
    }

    public String getJobnature() {
        return this.jobnature;
    }

    public void setJobnature(String jobnature) {
        this.jobnature = jobnature;
    }

    public String getExperencereq() {
        return this.experencereq;
    }

    public void setExperencereq(String experencereq) {
        this.experencereq = experencereq;
    }

    public String getJobpoststatus() {
        return this.jobpoststatus;
    }

    public void setJobpoststatus(String jobpoststatus) {
        this.jobpoststatus = jobpoststatus;
    }

    public String getOtherbenifit() {
        return this.otherbenifit;
    }

    public void setOtherbenifit(String otherbenifit) {
        this.otherbenifit = otherbenifit;
    }

    public String getUseremail() {
        return this.useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }

}
