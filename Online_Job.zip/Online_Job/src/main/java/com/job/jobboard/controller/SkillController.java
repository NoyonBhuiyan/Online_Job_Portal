package com.job.jobboard.controller;

import com.job.jobboard.model. Skill;

import com.job.jobboard.service.SkillService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/v1")
public class SkillController {

    @Autowired
    private SkillService areaService;

    @GetMapping("/skill")
    public List<Skill> getAllSkill() {
        return areaService.viewSkill();
    }

    @PostMapping("/skill")
    public Skill createSkill(@RequestBody Skill area) {
        return areaService.insertSkill(area);
    }

    @GetMapping("/skill/{skillid}")
    public ResponseEntity<Skill> getUser(@PathVariable("areaid") int areaid) {
        System.out.println("Fetching User with id " + areaid);
        Skill area = areaService.viewOneSkill(areaid);
        if (area == null) {
            System.out.println("Skill with id " + areaid + " not found");
            return new ResponseEntity<Skill>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Skill>(area, HttpStatus.OK);
    }

    @PutMapping("/skill/{skillid}")
    public ResponseEntity<Skill> updateUser(@PathVariable("areaid") int areaid, @RequestBody Skill area) {
        System.out.println("Updating Skill " + areaid);

        Skill currentSkill = areaService.viewOneSkill(areaid);

        if (currentSkill == null) {
            System.out.println("User with id " + areaid + " not found");
            return new ResponseEntity<Skill>(HttpStatus.NOT_FOUND);
        }

        currentSkill.setSkillname(area.getSkillname());
      
           currentSkill.setSkillid(area.getSkillid());
         currentSkill.setPersinfoid(area.getPersinfoid());

        areaService.updateSkill(currentSkill);
        return new ResponseEntity<Skill>(currentSkill, HttpStatus.OK);
    }

    @DeleteMapping("/skill/{skillid}")
    public ResponseEntity<Skill> deleteUser(@PathVariable("areaid") int areaid) {
        System.out.println("Fetching & Deleting Skill with id " + areaid);

        Skill area = areaService.viewOneSkill(areaid);
        if (area == null) {
            System.out.println("Unable to delete. Skill with id " + areaid + " not found");
            return new ResponseEntity<Skill>(HttpStatus.NOT_FOUND);
        }

        areaService.deleteSkill(areaid);
        return new ResponseEntity<Skill>(HttpStatus.NO_CONTENT);
    }

}
