package com.job.jobboard.controller;

import com.job.jobboard.model.Jobpost;

import com.job.jobboard.service.JobpostService;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/v1")
public class JobpostController {

    @Autowired
    private JobpostService areaService;

    @InitBinder
    public void myInitBinder(WebDataBinder binder) {
        //binder.setDisallowedFields(new String[]{"empMobile"});
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        binder.registerCustomEditor(Date.class, "startdate", new CustomDateEditor(format, false));
    }

    @InitBinder
    public void mytoInitBinder(WebDataBinder binder) {
        //binder.setDisallowedFields(new String[]{"empMobile"});
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        binder.registerCustomEditor(Date.class, "enddate", new CustomDateEditor(format, false));
    }

    @GetMapping("/jobpost")
    public List<Jobpost> getAllJobpost() {
        return areaService.viewJobpost();
    }

    @PostMapping("/jobpost")
    public Jobpost createJobpost(@RequestBody Jobpost area) {
        return areaService.insertJobpost(area);
    }

    @GetMapping("/jobpost/{jobpostid}")
    public ResponseEntity<Jobpost> getUser(@PathVariable("applyid") int areaid) {
        System.out.println("Fetching User with id " + areaid);
        Jobpost area = areaService.viewOneJobpost(areaid);
        if (area == null) {
            System.out.println("Jobpost with id " + areaid + " not found");
            return new ResponseEntity<Jobpost>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Jobpost>(area, HttpStatus.OK);
    }

    @PutMapping("/jobpost/{jobpostid}")
    public ResponseEntity<Jobpost> updateUser(@PathVariable("applyid") int areaid, @RequestBody Jobpost area) {
        System.out.println("Updating Jobpost " + areaid);

        Jobpost currentJobpost = areaService.viewOneJobpost(areaid);

        if (currentJobpost == null) {
            System.out.println("User with id " + areaid + " not found");
            return new ResponseEntity<Jobpost>(HttpStatus.NOT_FOUND);
        }

        currentJobpost.setEmpid(area.getEmpid());
        currentJobpost.setJobpostid(area.getJobpostid());
        currentJobpost.setJobpostid(area.getJobpostid());
        currentJobpost.setJobcatid(area.getJobcatid());
        currentJobpost.setJobtitle(area.getJobtitle());
        currentJobpost.setJoblocation(area.getJoblocation());
        currentJobpost.setNumofvacancy(area.getNumofvacancy());
        currentJobpost.setStartdate(area.getStartdate());
        currentJobpost.setEnddate(area.getEnddate());
        currentJobpost.setSkillreq(area.getSkillreq());
        currentJobpost.setEdureq(area.getEdureq());
        currentJobpost.setBasicreqm(area.getBasicreqm());
        currentJobpost.setJobnature(area.getJobnature());
        currentJobpost.setExperencereq(area.getExperencereq());
        currentJobpost.setJobpoststatus(area.getJobpoststatus());
        currentJobpost.setOtherbenifit(area.getOtherbenifit());
        currentJobpost.setUseremail(area.getUseremail());

        areaService.updateJobpost(currentJobpost);
        return new ResponseEntity<Jobpost>(currentJobpost, HttpStatus.OK);
    }

    @DeleteMapping("/jobpost/{jobpostid}")
    public ResponseEntity<Jobpost> deleteUser(@PathVariable("applyid") int areaid) {
        System.out.println("Fetching & Deleting Jobpost with id " + areaid);

        Jobpost area = areaService.viewOneJobpost(areaid);
        if (area == null) {
            System.out.println("Unable to delete. Jobpost with id " + areaid + " not found");
            return new ResponseEntity<Jobpost>(HttpStatus.NOT_FOUND);
        }

        areaService.deleteJobpost(areaid);
        return new ResponseEntity<Jobpost>(HttpStatus.NO_CONTENT);
    }

}
