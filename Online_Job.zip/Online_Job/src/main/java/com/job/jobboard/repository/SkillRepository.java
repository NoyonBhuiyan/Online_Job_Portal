package com.job.jobboard.repository;

import com.job.jobboard.model.Skill;
import com.job.jobboard.service.SkillService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class SkillRepository implements SkillService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Skill insertSkill(Skill cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(cm);
        t.commit();
        s.close();
        return cm;
    }

    @Override
    public void updateSkill(Skill cm) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(cm);
        t.commit();
        s.close();
    }

    @Override
    public void deleteSkill(int areaid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Skill cm = (Skill) s.get(Skill.class, areaid);
        s.delete(cm);
        t.commit();
        s.close();
    }

    @Override
    public List<Skill> viewSkill() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Skill> arealist = s.createQuery("from Skill").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return arealist;
    }

    @Override
    public Skill viewOneSkill(int areaid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Skill cm = (Skill) s.get(Skill.class, areaid);
        t.commit();
        s.close();
        return cm;
    }

    
    
}
