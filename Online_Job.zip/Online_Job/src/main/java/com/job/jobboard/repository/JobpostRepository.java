
package com.job.jobboard.repository;

import com.google.gson.Gson;
import com.job.jobboard.service.JobpostService;
import com.job.jobboard.model.Jobpost;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author B10
 */
@Repository
public class JobpostRepository implements JobpostService{
    
    @Autowired
    SessionFactory sessionFactory;

    @Override
    public Jobpost insertJobpost(Jobpost emphistory) {
      Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(emphistory);
        t.commit();
        s.close();
        return null;  
    }
    @Override
    public void updateJobpost(Jobpost emphistory) {
      Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
//        Jobpost oneemphistoryobject = (Jobpost) s.get(Jobpost.class, emphisid);
// 
//        oneemphistoryobject.setComcatid(emphistory.getComcatid());
//        oneemphistoryobject.setComcatname(emphistory.getComcatname());
//    
//       
//        oneemphistoryobject.setPosition(emphistory.getPosition());
//        oneemphistoryobject.setRespons(emphistory.getRespons());
//        oneemphistoryobject.setFromdate(emphistory.getFromdate());
//        oneemphistoryobject.setTodate(emphistory.getTodate());      
        s.update(emphistory);
        t.commit();
        s.close();
       
    }

    @Override
    public void deleteJobpost(int emphisid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Jobpost emphistory = (Jobpost) s.get(Jobpost.class, emphisid);
        s.delete(emphistory);
        t.commit();
        s.close();
        
    }

    @Override
    public List<Jobpost> viewJobpost() {
       Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Jobpost> emphistorylist = s.createQuery("from Jobpost").list();
//        Gson g = new Gson();
//        String emphistorylistlistgson = g.toJson(emphistorylist);
        t.commit();
        s.close();
        return emphistorylist;
    }

    @Override
    public Jobpost viewOneJobpost(int emphisid) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Jobpost emphistory = (Jobpost) s.get(Jobpost.class, emphisid);
        t.commit();
        s.close();
        return emphistory;
    }
    
}
