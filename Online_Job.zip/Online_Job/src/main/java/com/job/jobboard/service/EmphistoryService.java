
package com.job.jobboard.service;

import com.job.jobboard.model.Emphistory;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface EmphistoryService {

    public Emphistory insertEmphistory(Emphistory emphistory);

    public void updateEmphistory(Emphistory emphistory);

    public void deleteEmphistory(int emphisid);

    public List<Emphistory>viewEmphistory();

    public Emphistory viewOneEmphistory(int emphisid);

}
