
package com.job.jobboard.service;

import com.job.jobboard.model.Educationalinfo;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface EducationalinfoService {
     
    public  Educationalinfo insertEducationalinfo(Educationalinfo educationalinfo);

    public void updateEducationalinfo(Educationalinfo educationalinfo);

    public void deleteEducationalinfo(int eduid);

    public List<Educationalinfo> viewEducationalinfo();

    public Educationalinfo viewOneEducationalinfo(int eduid);
    
    
    
}
