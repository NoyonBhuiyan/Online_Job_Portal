/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.job.jobboard.repository;

import com.google.gson.Gson;
import com.job.jobboard.service.JobCategoryService;
import com.job.jobboard.model.JobCategory;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class JobCategoryRepository implements JobCategoryService{
    
    @Autowired
    SessionFactory sessionFactory;

    @Override
    public JobCategory insertJobCategory(JobCategory jc) {
     Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(jc);
        t.commit();
        s.close();
        return null;
    }

    @Override
    public void updateJobCategory(JobCategory jc) {
     Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //JobCategoriesModel cm = (JobCategoriesModel)s.get(JobCategoriesModel.class, jobcategoryid);
        s.update(jc);
        t.commit();
        s.close();
        
    }

    @Override
    public void deleteJobCategory(int jobcatid) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        JobCategory jc = (JobCategory) s.get(JobCategory.class, jobcatid);
        s.delete(jc);
        t.commit();
        s.close();

        
    }

    @Override
    public List<JobCategory>  viewJobCategory() {
    Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<JobCategory> jobcategorieslist = s.createQuery("from JobCategory").list();
//        Gson g = new Gson();
//        String jobcategorylistgson = g.toJson(jobcategorieslist);
        t.commit();
        s.close();
        //System.out.println(jobcategorylistgson);
        return jobcategorieslist;
    }

    @Override
    public JobCategory viewOneJobCategory(int jobcatid) {
     Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        JobCategory jc = (JobCategory) s.get(JobCategory.class, jobcatid);
        t.commit();
        s.close();
//        Gson g = new Gson();
//        String jobcategorygson = g.toJson(jc);
        return jc;
    }
    
}
