
package com.job.jobboard.service;

import com.job.jobboard.model.City;
import java.util.List;
import org.springframework.stereotype.Service;


@Service
public interface CityService {
    
    public City insertCity(City c);

    public void updateCity( City c);

    public void deleteCity(int cityid);

    public List<City> viewCity();

    public City viewOneCity(int cityid);
    
}
