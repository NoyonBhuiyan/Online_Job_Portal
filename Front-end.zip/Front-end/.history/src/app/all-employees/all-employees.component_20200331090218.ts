import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-all-employees',
  templateUrl: './all-employees.component.html',
  styleUrls: ['./all-employees.component.css']
})
export class AllEmployeesComponent implements OnInit {

  constructor(private router: Router) { }


List() {

  this.router.navigate(['/employee-list']);
}

Add() {

  this.router.navigate(['/ad-employee']);
}


  ngOnInit() {
  }

}
