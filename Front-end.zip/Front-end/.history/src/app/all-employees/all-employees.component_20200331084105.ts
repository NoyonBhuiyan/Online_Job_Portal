import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-employees',
  templateUrl: './all-employees.component.html',
  styleUrls: ['./all-employees.component.css']
})
export class AllEmployeesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
