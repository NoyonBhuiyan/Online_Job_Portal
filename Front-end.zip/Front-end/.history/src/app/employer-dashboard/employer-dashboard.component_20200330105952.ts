import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-employer-dashboard',
  templateUrl: './employer-dashboard.component.html',
  styleUrls: ['./employer-dashboard.component.css']
})
export class AddEmployeeComponent implements OnInit {
  router: any;

  constructor() { }

  ngOnInit() {
  }
  goback() {
    history.back();
  }

  toRegistration() {
    this.router.navigate(['/registration']);

  }


}
