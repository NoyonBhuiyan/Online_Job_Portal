export class Employee {






    constructor(
        public username: string = '',
        public gender: string = '',
        public phone: string = '',
        public email: string = '',
        public unapprovedChanges: boolean = false,
       
        ) {
        }

        }
      
      