export class Employee {

    // id: number;
    // username: String;
    // gender: String;
    // emailid: String;
    // phone: String;
    // password: String;




    constructor(
        public username: string = '',
        public gender: string = '',
        public phone: string = '',
        public email: string = '',
        public unapprovedChanges: boolean = false,

     ) {
        }

        }


