import { Component, OnInit, ViewChild } from '@angular/core';
import { Resume } from '../Model/resume';
import { ResumeService } from '../Services/resume.service';
import { Router } from '@angular/router';
import { $ } from 'protractor';
import { MatTableDataSource } from '@angular/material';
import {MatPaginator} from '@angular/material/paginator';

@Component({
  selector: 'app-cvbank',
  templateUrl: './cvbank.component.html',
  styleUrls: ['./cvbank.component.css']
})
export class CvbankComponent implements OnInit {

  // @ViewChild(MatPaginator ) paginator: MatPaginator;

  resume: Resume[];
  dataSource: any;
  // service: any;
  constructor(private service: ResumeService, private router: Router ) { }

  ngOnInit() {
  this.service.getAllResume();
  // this.dataSource.paginator = this.paginator;

this.service.getAllResume()
.subscribe  (data => {
  this.resume = data;
});

}


// $ (document)  ready(function () {
//   $('#dtHorizontalVerticalExample').DataTable({
//   'scrollX': true,
//   'scrollY': 200,
//   });
//   $('.dataTables_length').addClass('bs-select');
//   }



applyFilter(event: Event) {
  const filterValue = (event.target as HTMLInputElement).value;
  this.dataSource.filter = filterValue.trim().toLowerCase();
}


  goback() {
    history.back();
  }
}
