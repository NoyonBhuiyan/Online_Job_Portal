import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cvbank',
  templateUrl: './cvbank.component.html',
  styleUrls: ['./cvbank.component.css']
})
export class CvbankComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
