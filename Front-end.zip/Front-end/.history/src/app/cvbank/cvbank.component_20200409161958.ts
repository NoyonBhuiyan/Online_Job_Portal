import { Component, OnInit, ViewChild } from '@angular/core';
import { Resume } from '../Model/resume';
import { ResumeService } from '../Services/resume.service';
import { Router } from '@angular/router';
import { $, error } from 'protractor';
import { MatTableDataSource } from '@angular/material';
import {MatPaginator} from '@angular/material/paginator';

@Component({
  selector: 'app-cvbank',
  templateUrl: './cvbank.component.html',
  styleUrls: ['./cvbank.component.css']
})
export class CvbankComponent implements OnInit {


    resume: Resume[];




  // private gridApi;
  // public globalResponse: any;
  // isFailedMessage = false;
  // message: string;




// columnDefs = [
//   { headerName: 'Name', field: 'Name'},
//   { headerName: 'Employment Role', field: 'Employment Role'},
//   { headerName: 'Skills/Experience', field: 'Skills/Experience'},
//   { headerName: 'Concentration/Major', field: 'Concentration/Major'},
//   { headerName: 'Maritul Status', field: 'Maritul Status'},
//   { headerName: 'Present Address', field: 'Present Address'},
//  ];


//   rowData: [{}];
//   AllResumes: any;

  constructor(private Resumeservice: ResumeService, private router: Router ) {
    // this.getAllResume();
   }


  //  getAllResume() {
  //  this.Resumeservice.getAllResume()
  //  .subscribe((result) => {
  //    this.globalResponse = result;
  //  },
// tslint:disable-next-line:no-shadowed-variable
// error => {
//   console.log(error);
//   this.isFailedMessage = true;
//   this.message = 'Something Error. ';
// },
// () => {
//   this.AllResumes = this.globalResponse;
//   console.log(this.AllResumes);
//   this.rowData = this.AllResumes;
// }

//    );
//   }


  ngOnInit() {
  // this.Resumeservice.getAllResume();

  // this.dataSource.paginator = this.paginator;

 this.Resumeservice.getAllResume()
 .subscribe(  (data: Resume[]) => {
   this.resume = data;
 });

 }
//  getAllRoute(){
//   this.eticketService.getAllRoute().subscribe(
//     (data: Resume[]) => {
//       this.allRoute = data;
//     }
//   );
// }

// $ (document)  ready(function () {
//   $('#dtHorizontalVerticalExample').DataTable({
//   'scrollX': true,
//   'scrollY': 200,
//   });
//   $('.dataTables_length').addClass('bs-select');
//   }



// applyFilter(event: Event) {
//   const filterValue = (event.target as HTMLInputElement).value;
//   this.dataSource.filter = filterValue.trim().toLowerCase();
// }

editRoute(resume: Resume) {
this.Resumeservice.resume = resume;
this.router.navigate(['/resume']);

}

  goback() {
    history.back();
  }
}
