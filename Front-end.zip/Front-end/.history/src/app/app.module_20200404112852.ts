import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import { HttpClientModule} from '@angular/common/http';
import {LayoutModule} from '@angular/cdk/layout';
import {CdkTableModule} from '@angular/cdk/table';
import {MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
// 3rd party imports
import {AutosizeModule} from 'ngx-autosize';
import {MarkdownModule} from 'ngx-markdown';
import {AngularMarkdownEditorModule} from 'angular-markdown-editor';
import {Ng5SliderModule} from 'ng5-slider';
import {MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatDatepickerModule, MatMomentDateModule} from '@coachcare/datepicker';
// import {MAT_MOMENT_DATE_FORMATS} from './customCHLocale/moment-date-formats';
// Import css components from angular material
import {
  MatBadgeModule,
  MatButtonModule,
  MatCardModule,
  MatCheckboxModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  // MatPaginatorIntl,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTabsModule,
} from '@angular/material';
// Import all Components
import {AppComponent} from './app.component';
import {LoginComponent} from './login/login.component';
import {RegistrationComponent} from './registration/registration.component';
import {AppRoutingModule} from './app-routing.module';
import { UsersregistrationComponent } from './usersregistration/usersregistration.component';
import { MatNavComponent } from './mat-nav/mat-nav.component';
import { AddEmployeeComponent } from './employer-dashboard/employer-dashboard.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AllJobsComponent } from './all-jobs/all-jobs.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { PostResumeComponent } from './post-resume/post-resume.component';
import { ResumeComponent } from './resume/resume.component';
import { PostJobComponent } from './post-job/post-job.component';
import { RegisterComponent } from './register/register.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import {HttpClientModule} from '@angular/common/http';
import { AdEmployeeComponent } from './ad-employee/ad-employee.component';
import { AllEmployeesComponent } from './all-employees/all-employees.component';
import {EmployeeService} from './Services/employee.service';
import {EmployerService} from './Services/employer.service';
import { EmployerListComponent } from './employer-list/employer-list.component';
import { RegSuccessComponent } from './reg-success/reg-success.component';
import { UserregSuccessComponent } from './userreg-success/userreg-success.component';
import { JobListComponent } from './job-list/job-list.component';
import { JobsService } from './Services/jobs.service';
import { CvComponent } from './cv/cv.component';
import { ResumeService } from './Services/resume.service';
@NgModule({
  declarations: [
    AppComponent,
    // JobViewComponent,
    // JobViewDetailsComponent,
    // JobsViewComponent,
    // JobsAdvancedSearchComponent,
    // JobEditComponent,
    // JobsEditComponent,
    // SkillViewComponent,
    // SkillEditComponent,
    LoginComponent,
    // LogoutComponent,
    RegistrationComponent,
    // PageNotFoundComponent,
    // UsersEditComponent,
    // AccountSettingsComponent,
    // ConfirmDialogComponent,
    // JobsPaginatorPipe,
    // JobsSortPipe,
    // SelectLogoComponent,
    // JobsEditSortPipe,
    UsersregistrationComponent,
    MatNavComponent,
    AddEmployeeComponent,
    AdminDashboardComponent,
    AllJobsComponent,
    HomeComponent,
    FooterComponent,
    PostResumeComponent,
    ResumeComponent,
    PostJobComponent,
    RegisterComponent,
    EmployeeListComponent,
    AdEmployeeComponent,
    AllEmployeesComponent,
    EmployerListComponent,
    RegSuccessComponent,
    UserregSuccessComponent,
    JobListComponent,
    CvComponent,

  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    MatButtonModule,
    MatSliderModule,
    MatDatepickerModule,
    MatListModule,
    MatInputModule,
    MatCheckboxModule,
    MatCardModule,
    AutosizeModule,
    AppRoutingModule,
    MatDatepickerModule,
    MatMomentDateModule,
    Ng5SliderModule,
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatRadioModule,
    MatExpansionModule,
    MatStepperModule,
    MatGridListModule,
    MatBadgeModule,
    CdkTableModule,
    MatSnackBarModule,
    MatSelectModule,
    MarkdownModule.forRoot(),
    AngularMarkdownEditorModule.forRoot(),
    MatSlideToggleModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatTabsModule,
  ],
  entryComponents: [
    // JobViewDetailsComponent,
    // JobViewComponent,
    // JobsAdvancedSearchComponent,
    // ConfirmDialogComponent,
    // SelectLogoComponent,
  ],
  providers: [
     EmployeeService,
     EmployerService,
     JobsService,
     ResumeService,
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
    { provide: MAT_DATE_LOCALE, useValue: 'de-CH' },
    // { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
    // { provide: HTTP_INTERCEPTORS,  useClass: APIInterceptor, multi: true },
    // { provide: MatPaginatorIntl, useClass: CustomMatPaginatorIntl },

    ],
   bootstrap: [AppComponent]
})

export class AppModule {
}
