import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-jobs',
  templateUrl: './all-jobs.component.html',
  styleUrls: ['./all-jobs.component.css']
})
export class AllJobsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
