import { Component, OnInit } from '@angular/core';

export interface Location {
  value: string;
  display: string;
}


@Component({
  selector: 'app-all-jobs',
  templateUrl: './all-jobs.component.html',
  styleUrls: ['./all-jobs.component.css']
})
export class AllJobsComponent implements OnInit {


  selectedValue: string;
  locations: Location[] = [
     {value: 'dhaka', display: 'Dhaka'},
     {value: 'chittagong', display: 'Chittagong'},
     {value: 'sylhet', display: 'Sylhet'},
     {value: 'rajshahi', display: 'Rajshahi'},
     {value: 'cumilla', display: 'Cumilla'},
     {value: 'rangpur', display: 'Rangpur'},
     {value: 'mymensingh', display: 'Mymensingh'}

  ];


  constructor() { }

  ngOnInit() {
  }

}
