import { Component, OnInit } from '@angular/core';

export interface Location {
  value: string;
  display: string;
}


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  selectedValue: string;
  locations: Location[] = [
     {value: 'dhaka', display: 'Dhaka'},
     {value: 'chittagong', display: 'Chittagong'},
     {value: 'sylhet', display: 'Sylhet'},
     {value: 'rajshahi', display: 'Rajshahi'},
     {value: 'cumilla', display: 'Cumilla'},
     {value: 'rangpur', display: 'Rangpur'},
     {value: 'mymensingh', display: 'Mymensingh'}

  ];



  constructor() { }

  ngOnInit() {
  }

}
