import { Component, OnInit } from '@angular/core';
import { HomeService } from '../Services/home.service';
import { Jobs } from '../Model/jobs';
import { JobsService } from '../Services/jobs.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // selectedValue: string;
  // locations: Location[] = [
  //    {value: 'dhaka', display: 'Dhaka'},
  //    {value: 'chittagong', display: 'Chittagong'},
  //    {value: 'sylhet', display: 'Sylhet'},
  //    {value: 'rajshahi', display: 'Rajshahi'},
  //    {value: 'cumilla', display: 'Cumilla'},
  //    {value: 'rangpur', display: 'Rangpur'},
  //    {value: 'mymensingh', display: 'Mymensingh'}

  // ];

  allCat: Jobs[];

  constructor( public homeService: HomeService , private router: Router, public jobservice: JobsService ) { }


  ngOnInit() {
  }


assignCatName() {


}



 selectCatChange(event: string) {
   this.jobservice.jobCategory = event;
   this.jobservice.x = 1;

  }




  getJob(jobs: Jobs) {
this.homeService.jobs = jobs;

  }


}
