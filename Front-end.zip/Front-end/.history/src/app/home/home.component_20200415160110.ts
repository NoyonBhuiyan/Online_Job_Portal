import { Component, OnInit } from '@angular/core';
import { HomeService } from '../Services/home.service';
import { Jobs } from '../Model/jobs';
import { JobsService } from '../Services/jobs.service';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // selectedValue: string;
  // locations: Location[] = [
  //    {value: 'dhaka', display: 'Dhaka'},
  //    {value: 'chittagong', display: 'Chittagong'},
  //    {value: 'sylhet', display: 'Sylhet'},
  //    {value: 'rajshahi', display: 'Rajshahi'},
  //    {value: 'cumilla', display: 'Cumilla'},
  //    {value: 'rangpur', display: 'Rangpur'},
  //    {value: 'mymensingh', display: 'Mymensingh'}

  // ];

  allCat: Jobs[];

  constructor( public homeService: HomeService , public jobservice: JobsService ) { }


  ngOnInit() {
  }

  getAllJobsByCat() {

    this.homeService.getAllJobsByCat().subscribe(
      (data: Jobs[]) => {
        this.allCat = data;
      }
    );
  }
  getAllJobsBySearch() {

    this.homeService.getAllJobsByTextSear().subscribe(
      (data: Jobs[]) => {
        this.allCat = data;
      }
    );
  }

assignCatName() {


}



 selectCatChange(event: string) {
   this.homeService.jobCategory = event;
  console.log(this.homeService.jobCategory);
 this. getAllJobsByCat();
this.jobservice.allCatJobSer = this.allCat;
 this.clear();
 console.log(0);
 console.log(event);

  }
  textSearch() {

   console.log(this.homeService.textSearch);
  this. getAllJobsBySearch();
  this.clear();


   }

  clear() {

this.homeService.jobCategory = '';
this.homeService.textSearch = '';
  }
  // editRoute(jobs: Jobs) {
  //   this.jobservice.jobs = jobs;
  //   this.router.navigate(['/job-view']);

  //   }

  getJob(jobs: Jobs) {
this.homeService.jobs = jobs;

  }


}
