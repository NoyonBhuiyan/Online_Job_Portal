import { Component, OnInit } from '@angular/core';
import { HomeService } from '../Services/home.service';
import { Jobs } from '../Model/jobs';

// export interface Location {
//   value: string;
//   display: string;
// }


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // selectedValue: string;
  // locations: Location[] = [
  //    {value: 'dhaka', display: 'Dhaka'},
  //    {value: 'chittagong', display: 'Chittagong'},
  //    {value: 'sylhet', display: 'Sylhet'},
  //    {value: 'rajshahi', display: 'Rajshahi'},
  //    {value: 'cumilla', display: 'Cumilla'},
  //    {value: 'rangpur', display: 'Rangpur'},
  //    {value: 'mymensingh', display: 'Mymensingh'}

  // ];

  allRoute: Jobs[];

  constructor( public homeService: HomeService ) { }


  ngOnInit() {
  }

  getAllJobsByCat() {

    this.homeService.getAllJobsByCat().subscribe(
      (data: Jobs[]) => {
        this.allRoute = data;
      }
    );
  }

assignCatName() {


}



 selectCatChange(event: string) {
  // this.homeService.jobCategory = event;
  console.log(event);

  }

}
