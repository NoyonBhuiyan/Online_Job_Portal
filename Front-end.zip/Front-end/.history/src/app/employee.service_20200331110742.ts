import { Injectable } from '@angular/core';
import {HttpClientModule, HttpClient, } from '@angular/common/http';
// import { Employee } from './employee';
  import { Employee } from './Model/Employee';
// import { Employee } from '../employee';


// const headerOption = {
//   headers: new HttpHeaders({ 'Content-Type': 'application/json' })
// };


@Injectable({providedIn: 'root'})
export class EmployeeService {



  // mockUrl = 'http://localhost:8080/api/v1/employee';



  constructor( private http: HttpClient) { }

Url = 'http://localhost:8080/JobBoard/api/v1/employee';


 getAllEmployee() {
  return this.http.get<Employee[]>(this.Url);
 }
}
