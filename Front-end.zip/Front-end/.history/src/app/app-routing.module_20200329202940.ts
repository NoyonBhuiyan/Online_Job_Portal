import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {PageNotFoundComponent} from './page-not-found/page-not-found.component';
import { HomeComponent } from './home/home.component';
import {RegisterComponent } from './register/register.component';
import {RegistrationComponent} from './registration/registration.component';
import {UsersregistrationComponent} from './usersregistration/usersregistration.component';
import {LoginComponent} from './login/login.component';
// import {JobsEditComponent} from './jobsEdit/jobsEdit.component';
// import {JobsViewComponent} from './jobsView/jobsView.component';
import {LogoutComponent} from './logout/logout.component';
// import {UsersEditComponent} from './usersEdit/usersEdit.component';
// import {AccountSettingsComponent} from './accountSettings/accountSettings.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ResumeComponent } from './resume/resume.component';
import { PostResumeComponent } from './post-resume/post-resume.component';
import { AllJobsComponent } from './all-jobs/all-jobs.component';

import { PostJobComponent } from './post-job/post-job.component';

const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'resume', component: ResumeComponent },

  { path: 'all-jobs', component: AllJobsComponent },
  { path: 'post-job', component: PostJobComponent },
  { path: 'post-resume', component: PostResumeComponent },
  { path: 'usersregistration', component: UsersregistrationComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'admin-dashboard', component: AdminDashboardComponent },
  { path: 'add-employee', component: AddEmployeeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent},
  // { path: 'editJobs', component: JobsEditComponent },
  //  { path: 'viewJobs', component: JobsViewComponent },
  // { path: 'editUsers', component: UsersEditComponent},
  // { path: 'editAccount', component: AccountSettingsComponent},
  { path: '', redirectTo: '/viewJobs', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    )
  ],
  exports: [
    RouterModule
  ]
})

export class AppRoutingModule {}
