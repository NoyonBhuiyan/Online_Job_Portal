import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { HomeComponent } from './home/home.component';
import {RegisterComponent } from './register/register.component';
import {RegistrationComponent} from './registration/registration.component';
import {UsersregistrationComponent} from './usersregistration/usersregistration.component';
import {LoginComponent} from './login/login.component';
import { AddEmployeeComponent } from './employer-dashboard/employer-dashboard.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ResumeComponent } from './resume/resume.component';
import { PostResumeComponent } from './post-resume/post-resume.component';
import { AllJobsComponent } from './all-jobs/all-jobs.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { PostJobComponent } from './post-job/post-job.component';
import { AdEmployeeComponent } from './ad-employee/ad-employee.component';
import { AllEmployeesComponent } from './all-employees/all-employees.component';
import { RegSuccessComponent } from './reg-success/reg-success.component';
import { UserregSuccessComponent } from './userreg-success/userreg-success.component';
import { JobListComponent } from './job-list/job-list.component';
import { SubComponent } from './sub/sub.component';
import { CvbankComponent } from './cvbank/cvbank.component';



const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'employee-list', component: EmployeeListComponent },
  { path: 'resume', component: ResumeComponent },
  { path: 'all-jobs', component: AllJobsComponent },
  { path: 'post-job', component: PostJobComponent },
  { path: 'post-resume', component: PostResumeComponent },
  { path: 'usersregistration', component: UsersregistrationComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'job-list', component: JobListComponent },
  { path: 'admin-dashboard', component: AdminDashboardComponent },
  { path: 'add-employee', component: AddEmployeeComponent },
  { path: 'ad-employee', component: AdEmployeeComponent },
  { path: 'reg-success', component: RegSuccessComponent },
  { path: 'userreg-success', component: UserregSuccessComponent },
  { path: 'login', component: LoginComponent },
  { path: 'all-employees', component: AllEmployeesComponent },
  { path: 'sub', component: SubComponent },
  { path: 'cvbank', component: CvbankComponent },

  // { path: 'logout', component: LogoutComponent},
  // { path: 'editJobs', component: JobsEditComponent },
  //  { path: 'viewJobs', component: JobsViewComponent },
  // { path: 'editUsers', component: UsersEditComponent},
  // { path: 'editAccount', component: AccountSettingsComponent},
  // { path: '', redirectTo: '/viewJobs', pathMatch: 'full' },
  // { path: '**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    )
  ],
  exports: [
    RouterModule
  ]
})

export class AppRoutingModule {}
