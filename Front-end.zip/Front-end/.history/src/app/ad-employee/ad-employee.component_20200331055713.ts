import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ad-employee',
  templateUrl: './ad-employee.component.html',
  styleUrls: ['./ad-employee.component.css']
})
export class AdEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
