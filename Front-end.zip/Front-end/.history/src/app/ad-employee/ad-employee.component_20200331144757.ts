import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../shared/employee.service';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-ad-employee',
  templateUrl: './ad-employee.component.html',
  styleUrls: ['./ad-employee.component.css']
})
export class AdEmployeeComponent implements OnInit {

  constructor(private service: EmployeeService, private router: Router ) { }

  ngOnInit() {
  }




save(employee: Employee) {
this.service.insertEmployee(employee)
.subscribe(data => {
  alert('Saved Successfully !!!!');
  this.router.navigate(['/employee-list']);
});
  }




  goback() {
    history.back();
  }
}
