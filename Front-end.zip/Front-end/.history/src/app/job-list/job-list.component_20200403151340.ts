import { Component, OnInit } from '@angular/core';
import { JobsService } from '../Services/jobs.service';
import { Router } from '@angular/router';
import { Jobs } from '../Model/jobs';

@Component({
  selector: 'app-job-list',
  templateUrl: './job-list.component.html',
  styleUrls: ['./job-list.component.css']
})
export class JobListComponent implements OnInit {

  constructor(public jobservice: JobsService, private router: Router) { }

  ngOnInit() {
  }


  save(jobs: Jobs) {
     this.jobservice.postJobs(jobs)
    .subscribe();
    // alert ('Saved Successfully...!!!');
    // this.router.navigate(['/employee-list']);
    }


  goback() {
    history.back();
  }

}
