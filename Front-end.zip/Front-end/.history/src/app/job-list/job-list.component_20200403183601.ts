import { Component, OnInit } from '@angular/core';
import { JobsService } from '../Services/jobs.service';
import { Router } from '@angular/router';
import { Jobs } from '../Model/jobs';
import { MatSnackBar, MatDialog } from '@angular/material';

@Component({
  selector: 'app-job-list',
  templateUrl: './job-list.component.html',
  styleUrls: ['./job-list.component.css']
})
export class JobListComponent implements OnInit {

  constructor(public jobservice: JobsService, private router: Router, private snackBar: MatSnackBar, private dialog: MatDialog) { }

  ngOnInit() {
  }


  save(jobs: Jobs) {
     this.jobservice.postJobs(jobs)
    .subscribe();

    if (this.jobservice.jobs.jobtitle === '' ||  this.jobservice.jobs.startdate === ''
|| this.jobservice.jobs.startdate === '' || this.jobservice.jobs.enddate === ''
|| this.jobservice.jobs.edureq === '' || this.jobservice.jobs.useremail === '' ||
!this.jobservice.jobs.useremail.match('[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,10}$')) {
 this.snackBar.open('Form not completely filled out!', null, {duration: 5000});
return;
} else {
 alert ('Job Posted Successfully...!!!');
return;
// this.router.navigate(['/userreg-success']);

}

  }


  goback() {
    history.back();
  }

}



