import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../shared/employee.service';
import { Router } from '@angular/router';
import { Employee } from '../model/Employee';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

employees: Employee[];
  // service: any;
  constructor(private service: EmployeeService, private router: Router ) { }

  ngOnInit() {
  this.service.getAllEmployee();

this.service.getAllEmployee()
.subscribe  (data => {
  this.employees = data;
});

// this.service.refreshNeeded$.subscribe(() => {this.getAllEmployee(); });
// this.getAllEmployee();

  }

  goback() {
    history.back();
  }
  }






